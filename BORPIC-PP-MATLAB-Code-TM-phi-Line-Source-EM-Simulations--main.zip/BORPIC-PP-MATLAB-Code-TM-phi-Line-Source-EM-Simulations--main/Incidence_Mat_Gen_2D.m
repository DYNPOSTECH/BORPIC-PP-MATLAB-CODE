function C_mat_sp_mat=Incidence_Mat_Gen_2D(N_2,N_1,fac_edg)

C_mat_sp_i=zeros(3*N_2,1);
C_mat_sp_j=zeros(3*N_2,1);
C_mat_sp_v=zeros(3*N_2,1);
cnt=0;
for glb_j=1:N_2    
    for loc_k=1:3
        cnt=cnt+1;
        C_mat_sp_i(cnt)=glb_j;
        C_mat_sp_j(cnt)=fac_edg(glb_j,loc_k);
        C_mat_sp_v(cnt)=(-1)^(loc_k+1);
    end    
end
C_mat_sp_i(cnt+1:end)=[];
C_mat_sp_j(cnt+1:end)=[];
C_mat_sp_v(cnt+1:end)=[];

C_mat_sp_mat=sparse(C_mat_sp_i,C_mat_sp_j,C_mat_sp_v,N_2,N_1);

end