function C_mat_sp_mat=Incidence_Mat_Gen_2D_v2(N_2,N_1,fac_edg,pbc_edg_idx)

C_mat_sp_i=zeros(3*N_2,1);
C_mat_sp_j=zeros(3*N_2,1);
C_mat_sp_v=zeros(3*N_2,1);
cnt=0;
for glb_j=1:N_2    
    for loc_k=1:3
        cnt=cnt+1;
        C_mat_sp_i(cnt)=glb_j;
        [det,loc]=ismember(fac_edg(glb_j,loc_k),pbc_edg_idx(:,2));
        if det==1
            C_mat_sp_j(cnt)=pbc_edg_idx(loc,1);
        else
            C_mat_sp_j(cnt)=fac_edg(glb_j,loc_k);
        end
        C_mat_sp_v(cnt)=(-1)^(loc_k+1);
    end    
end
C_mat_sp_i(cnt+1:end)=[];
C_mat_sp_j(cnt+1:end)=[];
C_mat_sp_v(cnt+1:end)=[];

C_mat_sp_mat=sparse(C_mat_sp_i,C_mat_sp_j,C_mat_sp_v,N_2,N_1);

end