function [...
    vec_field]=...
    Field_interpolation_1_2D(...
    x_sample,y_sample,...
    DT,G_mat,x_vec,fac_edg)

%% Postprocessing
interp_point=[x_sample,y_sample];
interp_fac_idx_vec=pointLocation(DT,interp_point);    

interp_point_temp=interp_point;    
vec_field=Wh_1_interp_2D(interp_point_temp,interp_fac_idx_vec,G_mat,x_vec,fac_edg);

end