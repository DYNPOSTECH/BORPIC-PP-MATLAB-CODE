# BORPIC-PP-MATLAB-Code (TM phi line source EM simulations)
Body-of-revolution finite-element time-domain (FETD) scheme with a radial PML and lateral PBC boundary conditions.
