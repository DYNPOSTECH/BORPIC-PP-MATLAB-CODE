function eps_mass_sp_mat=Eps_mass_Mat_Gen_PML_BOR(N_1,N_2,fac_edg,fac_area,G_mat,cond_set,w_0,eps_r,fac_cent_crdn)

[eps_0,mu_0,eta_0,c]=Constants_func();

eps_mass_sp_i=zeros(20*N_1,1);
eps_mass_sp_j=zeros(20*N_1,1);
eps_mass_sp_v=zeros(20*N_1,1);
cnt_eps=0;
for i=1:N_2
    s_x=1+1i*cond_set(i,1)/w_0/eps_0;
    s_y=1+1i*cond_set(i,2)/w_0/eps_0;    
    
    pml_mat=zeros(2,2);
    pml_mat(1,1)=s_y/s_x;
    pml_mat(2,2)=s_x/s_y;    
    
    G_mat_temp=G_mat(:,:,i);
    
    vec_1=transpose(G_mat_temp(1,1:2));
    vec_2=transpose(G_mat_temp(2,1:2));
    vec_3=transpose(G_mat_temp(3,1:2));    
    
    loc_eps_mass_matrix=zeros(3,3);
    
    loc_eps_mass_matrix(1,1)=...
        2*transpose(vec_2)*pml_mat*vec_2-...
        1*transpose(vec_2)*pml_mat*vec_1-...
        1*transpose(vec_1)*pml_mat*vec_2+...
        2*transpose(vec_1)*pml_mat*vec_1;
    
    loc_eps_mass_matrix(1,2)=...
        2*transpose(vec_2)*pml_mat*vec_3-...
        1*transpose(vec_2)*pml_mat*vec_1-...
        1*transpose(vec_1)*pml_mat*vec_3+...
        1*transpose(vec_1)*pml_mat*vec_1;
    
    loc_eps_mass_matrix(1,3)=...
        1*transpose(vec_2)*pml_mat*vec_3-...
        1*transpose(vec_2)*pml_mat*vec_2-...
        2*transpose(vec_1)*pml_mat*vec_3+...
        1*transpose(vec_1)*pml_mat*vec_2;
    
    loc_eps_mass_matrix(2,1)=loc_eps_mass_matrix(1,2);
    
    loc_eps_mass_matrix(2,2)=...
        2*transpose(vec_3)*pml_mat*vec_3-...
        1*transpose(vec_3)*pml_mat*vec_1-...
        1*transpose(vec_1)*pml_mat*vec_3+...
        2*transpose(vec_1)*pml_mat*vec_1;
    
    loc_eps_mass_matrix(2,3)=...
        1*transpose(vec_3)*pml_mat*vec_3-...
        1*transpose(vec_3)*pml_mat*vec_2-...
        1*transpose(vec_1)*pml_mat*vec_3+...
        2*transpose(vec_1)*pml_mat*vec_2;
    
    loc_eps_mass_matrix(3,1)=loc_eps_mass_matrix(1,3);
    loc_eps_mass_matrix(3,2)=loc_eps_mass_matrix(2,3);
    
    loc_eps_mass_matrix(3,3)=...
        2*transpose(vec_3)*pml_mat*vec_3-...
        1*transpose(vec_3)*pml_mat*vec_2-...
        1*transpose(vec_2)*pml_mat*vec_3+...
        2*transpose(vec_2)*pml_mat*vec_2;
    
    loc_eps_mass_matrix=loc_eps_mass_matrix*2*fac_area(i)/24*eps_0*eps_r(i)*fac_cent_crdn(i,2);
    
    for ii=1:3
        glb_i_idx=fac_edg(i,ii);
        for jj=1:3
            glb_j_idx=fac_edg(i,jj);
            cnt_eps=cnt_eps+1;
            eps_mass_sp_i(cnt_eps)=glb_i_idx;
            eps_mass_sp_j(cnt_eps)=glb_j_idx;
            eps_mass_sp_v(cnt_eps)=loc_eps_mass_matrix(ii,jj);
        end
    end
end
eps_mass_sp_i(cnt_eps+1:end)=[];
eps_mass_sp_j(cnt_eps+1:end)=[];
eps_mass_sp_v(cnt_eps+1:end)=[];

eps_mass_sp_mat=sparse(eps_mass_sp_i,eps_mass_sp_j,eps_mass_sp_v,N_1,N_1);

end