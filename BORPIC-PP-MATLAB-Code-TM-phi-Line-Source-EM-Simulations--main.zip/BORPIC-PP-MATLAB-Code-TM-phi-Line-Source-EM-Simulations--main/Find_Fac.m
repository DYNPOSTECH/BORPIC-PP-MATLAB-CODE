function fac_idx = Find_Fac(pos,fac_cent_crdn,nod_crdn,fac_nod)
    dist = sqrt( (pos(1)-fac_cent_crdn(:,1)).^2 + (pos(2)-fac_cent_crdn(:,2)).^2  );
    [rrr,ccc]=sort(dist);

    in=0;
    cnt_wh=0;
    while in==0
        cnt_wh=cnt_wh+1;
        fac_idx = ccc(cnt_wh);
    
        xq=pos(1);
        yq=pos(2);
        xv=nod_crdn(fac_nod(fac_idx,:),1);
        yv=nod_crdn(fac_nod(fac_idx,:),2);
        [in,~]=inpolygon(xq,yq,xv,yv);
        if in==1
            break;
        end
        if cnt_wh>10
            fac_idx = -1;
            break;
        end
    end
end