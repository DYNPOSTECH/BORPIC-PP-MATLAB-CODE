function [u_set,v_set,w_val] = QR_UVW_eps_Converter(q_set,r_set,del_t,N_1)
tau = 2/del_t;

Lambda = (r_set(:,0+1) + tau*r_set(:,1+1));
Lambda_inv = 1./Lambda;

w_val = Lambda_inv.*(q_set(:,0+1) + tau*q_set(:,1+1));

u_set = zeros(N_1,1+1);
v_set = zeros(N_1,1+1);

u_set(:,0+1) = Lambda_inv.*( tau*r_set(:,1+1) );
u_set(:,1+1) = Lambda_inv.*( r_set(:,1+1) );

v_set(:,0+1) = Lambda_inv.*( tau*q_set(:,1+1) );
v_set(:,1+1) = Lambda_inv.*( q_set(:,1+1) );

end