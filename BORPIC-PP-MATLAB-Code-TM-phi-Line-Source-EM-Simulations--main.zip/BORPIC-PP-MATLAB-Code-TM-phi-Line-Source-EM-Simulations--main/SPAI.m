function A_eps_inv_SPAI_mat_sp=SPAI(A_eps_mat_sp, SP_A_eps_mat_sp, I_mat_sp, N_1)

A_eps_inv_SPAI_mat_sp = sparse(N_1,N_1);

for k=1:N_1
    m_k = full(SP_A_eps_mat_sp(:,k));
    J_col_ind_vec = find(m_k ~= 0);
    [I_row_ind_vec,~] = find(A_eps_mat_sp(:,J_col_ind_vec)~=0);
    A_bar = full(A_eps_mat_sp(I_row_ind_vec,J_col_ind_vec));
    
    e_k = full(I_mat_sp(:,k));
    e_bar_k = e_k(I_row_ind_vec);
    % m_bar_k = m_k(J_col_ind_vec);    
    m_bar_k_upd = A_bar\e_bar_k;    
    
    A_eps_inv_SPAI_mat_sp(J_col_ind_vec,k) = m_bar_k_upd;
end

end