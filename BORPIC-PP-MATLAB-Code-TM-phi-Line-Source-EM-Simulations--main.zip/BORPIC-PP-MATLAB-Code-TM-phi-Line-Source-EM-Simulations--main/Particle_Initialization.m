function [pos_bef,vel_bef,q_sp,m_sp]=Particle_Initialization()

[eps_0,mu_0,eta_0,c]=Constants_func();
q_e=-1.6e-19;
m_e=9.1e-31;

sp_fac=1e6;
pos_bef=[-0.25012355;.7500005012312354];
vel_bef=[0.02501123453215435;0.02505092318273982173;0.002512345]*c;
q_sp = q_e*sp_fac;
m_sp = m_e*sp_fac;

end