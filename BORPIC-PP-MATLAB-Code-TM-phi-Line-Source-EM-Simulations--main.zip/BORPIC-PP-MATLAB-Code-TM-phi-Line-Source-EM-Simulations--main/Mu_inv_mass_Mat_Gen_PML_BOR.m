function mu_inv_mass_sp_mat=Mu_inv_mass_Mat_Gen_PML_BOR(N_2,fac_area,cond_set,w_0,fac_cent_crdn)

[eps_0,mu_0,eta_0,c]=Constants_func();

mu_inv_mass_sp_i=zeros(10*N_2,1);
mu_inv_mass_sp_j=zeros(10*N_2,1);
mu_inv_mass_sp_v=zeros(10*N_2,1);
cnt_mu_inv=0;
for i=1:N_2
    s_x=1+1i*cond_set(i,1)/w_0/eps_0;
    s_y=1+1i*cond_set(i,2)/w_0/eps_0;    
    s_z=1/s_x/s_y;

    loc_mu_inv_mass_val=1/fac_area(i)/mu_0*s_z*fac_cent_crdn(i,2);
    
    cnt_mu_inv=cnt_mu_inv+1;
    mu_inv_mass_sp_i(cnt_mu_inv)=i;
    mu_inv_mass_sp_j(cnt_mu_inv)=i;
    mu_inv_mass_sp_v(cnt_mu_inv)=loc_mu_inv_mass_val;
end
mu_inv_mass_sp_i(cnt_mu_inv+1:end)=[];
mu_inv_mass_sp_j(cnt_mu_inv+1:end)=[];
mu_inv_mass_sp_v(cnt_mu_inv+1:end)=[];

mu_inv_mass_sp_mat=sparse(mu_inv_mass_sp_i,mu_inv_mass_sp_j,mu_inv_mass_sp_v,N_2,N_2);

end