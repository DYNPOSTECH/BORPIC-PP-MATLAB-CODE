function f_inc_vec_sp=Plane_wave_excitation_2D(...
    w_0,k_inc_unit_vec,pol_unit_vec,E_0,...
    GC_order_p,...
    N_2,N_1,X_mat,G_mat,fac_edg,...
    fac_pml_idx,fac_area,eps_r)

[eps_0,mu_0,eta_0,c]=Constants_func();

k_inc_vec=w_0/c*k_inc_unit_vec;

a_vec=cross([k_inc_unit_vec,0], cross([k_inc_unit_vec,0],[pol_unit_vec,0]) );
b_vec=[pol_unit_vec,0];

a_vec=a_vec(1:2);
b_vec=b_vec(1:2);

[GC_w_set,GC_bc_set,GC_M]=GC_triangle(GC_order_p);

f_inc_vec=zeros(N_1,1);
loc_edg_nod_idx_set=[1,2; 1,3; 2,3];
for i=1:N_2
    if sum(fac_pml_idx(i,:))==0
        X_mat_temp=X_mat(1:2,:,i);
        G_mat_temp=G_mat(:,1:2,i);
        for j=1:3
            edg_idx=fac_edg(i,j);

            loc_grad_bc_a=transpose(G_mat_temp(loc_edg_nod_idx_set(j,1),:));
            loc_grad_bc_b=transpose(G_mat_temp(loc_edg_nod_idx_set(j,2),:));

            int_val_1_a=0;
            int_val_1_b=0;

            for ii=1:GC_M
                int_val_1_a=int_val_1_a+...
                    GC_w_set(ii)*...
                    GC_bc_set(ii,loc_edg_nod_idx_set(j,1))*...
                    E_0*...
                    exp( 1i*(k_inc_vec(1:2))*...
                         X_mat_temp*transpose(GC_bc_set(ii,:)) );

                int_val_1_b=int_val_1_b+...
                    GC_w_set(ii)*...
                    GC_bc_set(ii,loc_edg_nod_idx_set(j,2))*...
                    E_0*...
                    exp( 1i*(k_inc_vec(1:2))*...
                         X_mat_temp*transpose(GC_bc_set(ii,:)) );
            end
            int_val_1_a=int_val_1_a*fac_area(i)*2;
            int_val_1_b=int_val_1_b*fac_area(i)*2;

            f_inc_vec(edg_idx,1)=f_inc_vec(edg_idx,1)+...
                ( int_val_1_a*dot(loc_grad_bc_b,a_vec)...
                 -int_val_1_b*dot(loc_grad_bc_a,a_vec) )*...
                w_0^2*eps_0;

            f_inc_vec(edg_idx,1)=f_inc_vec(edg_idx,1)+...
                ( int_val_1_a*dot(loc_grad_bc_b,b_vec)...
                 -int_val_1_b*dot(loc_grad_bc_a,b_vec) )*...
                w_0^2*eps_0*eps_r(i);
        end
    end
end

f_inc_vec_sp=sparse(f_inc_vec);

end