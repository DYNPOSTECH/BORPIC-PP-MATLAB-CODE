function j_bef=Scatter(...
    pos_bef,pos_aft,fac_idx_pos_bef,fac_idx_pos_aft,...
    G_mat,q_sp,del_t,fac_edg,fac_edg_org,nod_crdn,edg_nod,edg_fac_up_dn,...
    j_bef)

if fac_idx_pos_bef==fac_idx_pos_aft 
    % CASE A
    G_mat_temp = G_mat(:,:,fac_idx_pos_bef);
    lambda_loc_s=G_mat_temp*[pos_bef;1];
    lambda_loc_f=G_mat_temp*[pos_aft;1];

    j_loc=Calc_Scatter_Current(lambda_loc_s,lambda_loc_f,q_sp,del_t);
    for j=1:3
        j_bef(fac_edg(fac_idx_pos_bef,j),1)=j_bef(fac_edg(fac_idx_pos_bef,j),1)+j_loc(j);
    end                

elseif fac_idx_pos_bef~=fac_idx_pos_aft && fac_idx_pos_aft~=-1 
    % CASE B 
    fac_idx_pos_bef_temp = fac_idx_pos_bef;            
    pos_bef_temp = pos_bef;
    cnt_wh=0;
    while fac_idx_pos_bef_temp ~= fac_idx_pos_aft
        cnt_wh=cnt_wh+1;       

        [cross_edg_idx,x_crs,y_crs] = Cross_Edg_Idx_Finder_v2(...
                pos_bef_temp,pos_aft,fac_idx_pos_bef_temp,fac_edg,edg_nod,nod_crdn,fac_edg_org);

        rr_idx = find(fac_idx_pos_bef_temp == edg_fac_up_dn(cross_edg_idx,:));
        fac_idx_temp = edg_fac_up_dn(cross_edg_idx,rr_idx);                  

        pos_aft_temp = [x_crs;y_crs];
        G_mat_temp = G_mat(:,:,fac_idx_temp);
        lambda_loc_s=G_mat_temp*[pos_bef_temp;1];
        lambda_loc_f=G_mat_temp*[pos_aft_temp;1];

        j_loc=Calc_Scatter_Current(lambda_loc_s,lambda_loc_f,q_sp,del_t);
        for j=1:3
            j_bef(fac_edg(fac_idx_temp,j),1)=j_bef(fac_edg(fac_idx_temp,j),1)+j_loc(j);
        end

        % next 
        rr_idx = find(fac_idx_pos_bef_temp ~= edg_fac_up_dn(cross_edg_idx,:));
        fac_idx_pos_bef_temp = edg_fac_up_dn(cross_edg_idx,rr_idx);
        pos_bef_temp = pos_aft_temp;                

        if cnt_wh>20                                        
            error2
        end                
    end
    fac_idx_temp = fac_idx_pos_bef_temp;
    pos_aft_temp = pos_aft;
    G_mat_temp = G_mat(:,:,fac_idx_temp);
    lambda_loc_s=G_mat_temp*[pos_bef_temp;1];
    lambda_loc_f=G_mat_temp*[pos_aft_temp;1];

    j_loc=Calc_Scatter_Current(lambda_loc_s,lambda_loc_f,q_sp,del_t);
    for j=1:3
        j_bef(fac_edg(fac_idx_pos_bef,j),1)=j_bef(fac_edg(fac_idx_pos_bef,j),1)+j_loc(j);
    end    

    if fac_idx_temp ~= fac_idx_pos_aft
        error
    end
elseif  fac_idx_pos_aft==-1 
    % CASE C            
    fac_idx_pos_bef_temp = fac_idx_pos_bef;            
    pos_bef_temp = pos_bef;
    cnt_wh = 0;
    pbc_det = 0;
    cross_edg_idx_org=0;
    while fac_idx_pos_bef_temp ~= fac_idx_pos_aft
        cnt_wh=cnt_wh+1;       

        [cross_edg_idx,x_crs,y_crs] = Cross_Edg_Idx_Finder_v2(...
                pos_bef_temp,pos_aft,fac_idx_pos_bef_temp,fac_edg,edg_nod,nod_crdn,fac_edg_org);
        cross_edg_idx_org = cross_edg_idx;

        if bc_edg(cross_edg_idx) == 3 && pbc_det == 0                                                           
            x_crs_new = x_crs + L_x_tot;
            y_crs_new = y_crs;
        end
        if bc_edg(cross_edg_idx) == 4 && pbc_det == 0
            rr=find(cross_edg_idx == pbc_rig_edg_idx);
            cross_edg_idx_org = cross_edg_idx;
            cross_edg_idx = pbc_lef_edg_idx(rr);
            x_crs_new = x_crs - L_x_tot;
            y_crs_new = y_crs;
        end

        if bc_edg(cross_edg_idx) == 4 && pbc_det == 1
            rr=find(cross_edg_idx == pbc_rig_edg_idx);
            cross_edg_idx = pbc_lef_edg_idx(rr);
        end

        rr_idx = find(fac_idx_pos_bef_temp == edg_fac_up_dn(cross_edg_idx,:));                
        fac_idx_temp = edg_fac_up_dn(cross_edg_idx,rr_idx);            

        pos_aft_temp = [x_crs;y_crs];
        G_mat_temp = G_mat(:,:,fac_idx_temp);
        lambda_loc_s=G_mat_temp*[pos_bef_temp;1];
        lambda_loc_f=G_mat_temp*[pos_aft_temp;1];

        j_loc=Calc_Scatter_Current(lambda_loc_s,lambda_loc_f,q_sp,del_t);
        for j=1:3
            j_bef(fac_edg(fac_idx_temp,j),1)=j_bef(fac_edg(fac_idx_temp,j),1)+j_loc(j);
        end

        % next 
        fac_idx_pos_bef_temp_org =  fac_idx_pos_bef_temp;
        rr_idx = find(fac_idx_pos_bef_temp ~= edg_fac_up_dn(cross_edg_idx,:));
        fac_idx_pos_bef_temp = edg_fac_up_dn(cross_edg_idx,rr_idx);
        
        if fac_idx_pos_bef_temp == 0
            if bc_edg(cross_edg_idx)==1 || bc_edg(cross_edg_idx)==2                        
                fac_idx_pos_bef_temp = fac_idx_pos_bef_temp_org;
            else 
                erorr3
            end
        end

        if bc_edg(cross_edg_idx) == 4 && pbc_det == 0                    
            cross_edg_idx = cross_edg_idx_org;
        end

        if bc_edg(cross_edg_idx)==0 || pbc_det == 1% no boundary
            pos_bef_temp = pos_aft_temp;
        else % boundary
            cross_edg_idx = cross_edg_idx_org;
            if bc_edg(cross_edg_idx)==1 && pbc_det == 0 % bottom reflecting (1)
                pos_bef_temp = pos_aft_temp;
                pos_aft(2)=r_min + (r_min-pos_aft(2));
                vel_aft(2) = -vel_aft(2);
                fac_idx_pos_aft = Find_Fac(pos_aft,fac_cent_crdn,nod_crdn,fac_nod);                                        
                pbc_det=1;
            elseif bc_edg(cross_edg_idx)==2  && pbc_det == 0% top (12)                        
                pos_bef_temp = pos_aft_temp;
                if top_reflecting_opt == 0
                    pos_aft(2)= r_max - (pos_aft(2) - r_max);
                elseif top_reflecting_opt == 1
                    pos_aft(2)= L_y_tot - (pos_aft(2) - L_y_tot);
                end
                vel_aft(2) = -vel_aft(2);
                fac_idx_pos_aft = Find_Fac(pos_aft,fac_cent_crdn,nod_crdn,fac_nod);                        
                pbc_det=1;
            elseif bc_edg(cross_edg_idx)==3  && pbc_det == 0% left (11)
                pos_bef_temp = [x_crs_new;y_crs_new];
                pos_aft(1)= pos_aft(1) + L_x_tot;
                fac_idx_pos_aft = Find_Fac(pos_aft,fac_cent_crdn,nod_crdn,fac_nod);
                pbc_det = 1; 
            elseif bc_edg(cross_edg_idx)==4  && pbc_det == 0% rigt (12)
                pos_bef_temp = [x_crs_new;y_crs_new];
                pos_aft(1)= pos_aft(1) - L_x_tot;
                fac_idx_pos_aft = Find_Fac(pos_aft,fac_cent_crdn,nod_crdn,fac_nod);
                pbc_det = 1; 
            end
        end

        if cnt_wh>20
            figure(100);
            plot(pos_bef(1),pos_bef(2),'xr');hold on;
            plot(pos_aft(1),pos_aft(2),'ob');hold on;  
            plot(edg_x,edg_y,'k');
            axis equal;
            
            error2
        end
        
    end
    fac_idx_temp = fac_idx_pos_bef_temp;
    pos_aft_temp = pos_aft;
    G_mat_temp = G_mat(:,:,fac_idx_temp);
    lambda_loc_s=G_mat_temp*[pos_bef_temp;1];
    lambda_loc_f=G_mat_temp*[pos_aft_temp;1];

    j_loc=Calc_Scatter_Current(lambda_loc_s,lambda_loc_f,q_sp,del_t);
    for j=1:3
        j_bef(fac_edg(fac_idx_pos_bef,j),1)=j_bef(fac_edg(fac_idx_pos_bef,j),1)+j_loc(j);
    end    
    if fac_idx_temp ~= fac_idx_pos_aft
        error
    end
else
    error            
end

end