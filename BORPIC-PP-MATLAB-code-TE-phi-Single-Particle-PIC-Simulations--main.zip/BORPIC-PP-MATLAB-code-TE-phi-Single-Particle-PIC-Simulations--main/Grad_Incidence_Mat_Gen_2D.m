function G_mat_sp_mat=Grad_Incidence_Mat_Gen_2D(N_1,N_0,edg_nod)

G_mat_sp_i=zeros(2*N_1,1);
G_mat_sp_j=zeros(2*N_1,1);
G_mat_sp_v=zeros(2*N_1,1);
cnt=0;
for glb_j=1:N_1    
    for loc_k=1:2
        cnt=cnt+1;
        G_mat_sp_i(cnt)=glb_j;
        G_mat_sp_j(cnt)=edg_nod(glb_j,loc_k);
        G_mat_sp_v(cnt)=(-1)^(loc_k+1);
    end    
end
G_mat_sp_i(cnt+1:end)=[];
G_mat_sp_j(cnt+1:end)=[];
G_mat_sp_v(cnt+1:end)=[];

G_mat_sp_mat=sparse(G_mat_sp_i,G_mat_sp_j,G_mat_sp_v,N_1,N_0);

end