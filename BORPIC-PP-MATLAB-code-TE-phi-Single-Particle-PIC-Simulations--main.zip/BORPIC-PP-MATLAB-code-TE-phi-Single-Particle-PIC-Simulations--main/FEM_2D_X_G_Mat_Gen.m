function [X_mat,G_mat,fac_area]=FEM_2D_X_G_Mat_Gen(N_2,fac_nod,nod_crdn)

X_mat=ones(3,3,N_2);
G_mat=zeros(3,3,N_2);
fac_area=zeros(N_2,1);
for i=1:N_2
    loc_fac_nod_crdn=nod_crdn(fac_nod(i,:),:);
    loc_fac_nod_crdn=transpose(loc_fac_nod_crdn);
    X_mat(1:2,:,i)=loc_fac_nod_crdn;
    X_mat_temp=X_mat(:,:,i);
    G_mat_temp=inv(X_mat_temp);
    G_mat(:,:,i)=G_mat_temp;
    fac_area(i)=abs(det(X_mat_temp))/2;
end

end