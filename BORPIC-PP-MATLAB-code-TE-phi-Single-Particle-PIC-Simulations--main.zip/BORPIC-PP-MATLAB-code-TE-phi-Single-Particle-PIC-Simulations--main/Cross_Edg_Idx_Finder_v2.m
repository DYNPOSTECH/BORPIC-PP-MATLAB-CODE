function [cross_edg_idx,x_crs,y_crs] = Cross_Edg_Idx_Finder_v2(...
    pos_bef,pos_aft,fac_idx,fac_edg,edg_nod,nod_crdn,fac_edg_org)

x_trj = [pos_bef(1) pos_aft(1)]; 
y_trj = [pos_bef(2) pos_aft(2)]; 

for loc_edg_idx = 1:3
%     edg_idx = fac_edg(fac_idx,loc_edg_idx);
    edg_idx = fac_edg_org(fac_idx,loc_edg_idx);
    
    edg_x_a = nod_crdn(edg_nod(edg_idx,1),1);
    edg_x_b = nod_crdn(edg_nod(edg_idx,2),1);
    edg_y_a = nod_crdn(edg_nod(edg_idx,1),2);
    edg_y_b = nod_crdn(edg_nod(edg_idx,2),2);
    
    edg_x = [edg_x_a,edg_x_b];
    edg_y = [edg_y_a,edg_y_b];
    
    l1=[x_trj(1),y_trj(1),x_trj(2),y_trj(2)];
    l2=[edg_x(1),edg_y(1),edg_x(2),edg_y(2)];
    
    [x_crs,y_crs] = line_intersection(l1,l2);
    
    if isnan(x_crs) || isinf(x_crs) || isnan(y_crs) || isinf(y_crs)% no cross    
    else
        x_trj_small = min(x_trj);
        x_trj_large = max(x_trj);
        y_trj_small = min(y_trj);
        y_trj_large = max(y_trj);
        if x_crs >= x_trj_small && x_crs <= x_trj_large && y_crs >= y_trj_small && y_crs <= y_trj_large
            cross_edg_idx = edg_idx;
            break;
        end
    end
end