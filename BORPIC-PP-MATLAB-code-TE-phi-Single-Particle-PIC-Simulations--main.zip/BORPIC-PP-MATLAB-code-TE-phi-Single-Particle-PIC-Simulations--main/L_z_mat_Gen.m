function L_z_mat_sp_mat=L_z_mat_Gen(N_2,fac_area)

[eps_0,mu_0,eta_0,c]=Constants_func();

L_z_mat_sp_i=zeros(10*N_2,1);
L_z_mat_sp_j=zeros(10*N_2,1);
L_z_mat_sp_v=zeros(10*N_2,1);
cnt_mu_inv=0;
for i=1:N_2    
    loc_L_z_mat_val=1/fac_area(i);
    
    cnt_mu_inv=cnt_mu_inv+1;
    L_z_mat_sp_i(cnt_mu_inv)=i;
    L_z_mat_sp_j(cnt_mu_inv)=i;
    L_z_mat_sp_v(cnt_mu_inv)=loc_L_z_mat_val;
end
L_z_mat_sp_i(cnt_mu_inv+1:end)=[];
L_z_mat_sp_j(cnt_mu_inv+1:end)=[];
L_z_mat_sp_v(cnt_mu_inv+1:end)=[];

L_z_mat_sp_mat=sparse(L_z_mat_sp_i,L_z_mat_sp_j,L_z_mat_sp_v,N_2,N_2);

end