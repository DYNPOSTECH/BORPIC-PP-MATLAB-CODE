function [...
    interp_crdn_x,interp_crdn_y,...
    interp_vec_field_x,interp_vec_field_y]=...
    Scattered_field_interpolation_3_2D(...
    N_x_interp,N_y_interp,...
    L_x_st,L_x_end,L_y_st,L_y_end,...
    DT,G_mat,x_vec,fac_edg)

%% Postprocessing
del_x_fac=(L_x_end-L_x_st)*1e-15;
del_y_fac=(L_y_end-L_y_st)*1e-15;

x_set=linspace(L_x_st+del_x_fac,L_x_end-del_x_fac,N_x_interp);
y_set=linspace(L_y_st+del_y_fac,L_y_end-del_y_fac,N_y_interp);

% x_set=linspace(L_x_st*0.9,L_x_end*0.9,N_x_interp);
% y_set=linspace(L_y_st*0.9,L_y_end*0.9,N_y_interp);

[interp_crdn_x,interp_crdn_y]=...
        meshgrid( x_set,y_set ); % xy plane at z=0.5
    
interp_crdn_x=interp_crdn_x(2:end-1,2:end-1);
interp_crdn_y=interp_crdn_y(2:end-1,2:end-1);

N_x_interp_re=N_x_interp-2;
N_y_interp_re=N_y_interp-2;

N_tot_interp=length(interp_crdn_x(:));

interp_crdn_x_vec=interp_crdn_x(:);
interp_crdn_y_vec=interp_crdn_y(:);

interp_point=[interp_crdn_x_vec,interp_crdn_y_vec];
interp_fac_idx_vec=pointLocation(DT,interp_point);    

interp_vec_field_x_vec=zeros(N_tot_interp,1);
interp_vec_field_y_vec=zeros(N_tot_interp,1);

for i=1:N_tot_interp
    interp_point_temp=interp_point(i,:);    
    vec_field=Wh_1_interp_2D(interp_point_temp,interp_fac_idx_vec(i),G_mat,x_vec,fac_edg);
    
    interp_vec_field_x_vec(i)=vec_field(1);
    interp_vec_field_y_vec(i)=vec_field(2);
end
interp_vec_field_x=reshape(interp_vec_field_x_vec,[N_x_interp_re,N_y_interp_re]);
interp_vec_field_y=reshape(interp_vec_field_y_vec,[N_x_interp_re,N_y_interp_re]);
end