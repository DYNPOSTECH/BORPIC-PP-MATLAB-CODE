function [u_eps_set,v_eps_set] = ...
    UV_eps_set(N_1_pml,edg_pml_fac_up_down,up_down_opt,x_y_opt,del_t,cond_set,eps_r)

[eps_0,mu_0,eta_0,c]=Constants_func();

if x_y_opt==1
    opos_x_y_opt=2;
elseif x_y_opt==2
    opos_x_y_opt=1;
end

r_eps_set = zeros(N_1_pml,1);
q_eps_set = zeros(N_1_pml,1);

fac_idx=edg_pml_fac_up_down(:,up_down_opt);
no_fac_edg_idx=find(fac_idx==0);
fac_idx(no_fac_edg_idx)=1;

r_eps_set(:,0+1) = cond_set(fac_idx,x_y_opt);
r_eps_set(:,1+1) = eps_0;

q_eps_set(:,0+1) = cond_set(fac_idx,opos_x_y_opt).*eps_r(fac_idx);
q_eps_set(:,1+1) = eps_0*eps_r(fac_idx);

[u_eps_set,v_eps_set,~] = QR_UVW_eps_Converter(q_eps_set,r_eps_set,del_t,N_1_pml);
u_eps_set(no_fac_edg_idx)=0;
v_eps_set(no_fac_edg_idx)=0;

end
