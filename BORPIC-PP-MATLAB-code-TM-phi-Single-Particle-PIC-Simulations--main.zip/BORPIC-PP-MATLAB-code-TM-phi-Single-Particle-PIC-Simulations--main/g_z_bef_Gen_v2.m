function g_z_mu_sp = ...
    g_z_bef_Gen_v2(N_2_pml,del_t,b_dof_sp_set,h_dof_sp_set,cond_set,mu_r,fac_pml_idx)

[eps_0,mu_0,eta_0,c]=Constants_func();

% g_z_mu = zeros(N_2_pml,1);
r_mu_set=zeros(N_2_pml,3);
q_mu_set=zeros(N_2_pml,3);

r_mu_set(:,0+1) = cond_set(fac_pml_idx,1).*cond_set(fac_pml_idx,2);
r_mu_set(:,1+1) = eps_0*(cond_set(fac_pml_idx,1) + cond_set(fac_pml_idx,2));
r_mu_set(:,2+1) = eps_0^2;

q_mu_set(:,0+1) = 0;
q_mu_set(:,1+1) = 0;
q_mu_set(:,2+1) = eps_0^2./mu_r(fac_pml_idx); 

[u_mu_set,v_mu_set,~] = QR_UVW_mu_Converter(q_mu_set,r_mu_set,del_t,N_2_pml);

g_z_mu = sum(h_dof_sp_set.*u_mu_set,2) - sum(b_dof_sp_set.*v_mu_set,2);
g_z_mu_sp = sparse(g_z_mu);
% for i=1:N_2_pml    
%     r_mu_set=zeros(3,1);
%     q_mu_set=zeros(3,1);
%     
%     r_mu_set(0+1) = cond_set(i,1)*cond_set(i,2);
%     r_mu_set(1+1) = eps_0*(cond_set(i,1) + cond_set(i,2));
%     r_mu_set(2+1) = eps_0^2;
% 
%     q_mu_set(0+1) = 0;
%     q_mu_set(1+1) = 0;
%     q_mu_set(2+1) = eps_0^2/mu_r(i);        
% 
%     [u_mu_set,v_mu_set,~] = QR_UVW_mu_Converter(q_mu_set,r_mu_set,del_t);
% 
%     g_z_mu(i) = ...
%         u_mu_set(0+1)*h_dof_sp_set(i,0+1) - v_mu_set(0+1)*b_dof_sp_set(i,0+1) + ...
%         u_mu_set(1+1)*h_dof_sp_set(i,1+1) - v_mu_set(1+1)*b_dof_sp_set(i,1+1) + ...    
%         u_mu_set(2+1)*h_dof_sp_set(i,2+1) - v_mu_set(2+1)*b_dof_sp_set(i,2+1);    
% end


end