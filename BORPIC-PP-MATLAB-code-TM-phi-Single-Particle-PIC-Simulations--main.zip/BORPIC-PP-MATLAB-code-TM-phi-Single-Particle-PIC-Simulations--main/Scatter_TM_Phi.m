function j_bef=Scatter_TM_Phi(pos_mid,fac_cent_crdn,nod_crdn,fac_nod,pat_l,j_bef,q_sp,vel_aft,fac_area,n_vec_sign,particle_shape_opt)

if particle_shape_opt==1
    N_fac = 10;            
    fac_close_idx = Find_Few_Faces_Close_to_Point(pos_mid,fac_cent_crdn,N_fac);
    % Scatter        
    for fac_i_idx=1:N_fac
        ii=fac_close_idx(fac_i_idx);

        x_fac=nod_crdn(fac_nod(ii,:),1);
        y_fac=nod_crdn(fac_nod(ii,:),2);
        polyface = polyshape(x_fac,y_fac);

        x_pat = [pos_mid(1)-pat_l,pos_mid(1)-pat_l,pos_mid(1)+pat_l,pos_mid(1)+pat_l];
        y_pat = [pos_mid(2)-pat_l,pos_mid(2)+pat_l,pos_mid(2)+pat_l,pos_mid(2)-pat_l];
        polypatch = polyshape(x_pat,y_pat);

        polyout = intersect(polyface,polypatch);
        if polyout.NumRegions==1
            overlapped_area = polyarea(polyout.Vertices(:,1),polyout.Vertices(:,2));
            j_bef(ii)=q_sp*vel_aft(3)*(overlapped_area/fac_area(ii))*n_vec_sign(ii);
        end
    end
elseif particle_shape_opt==0
    fac_mid_idx = Find_Fac(pos_mid,fac_cent_crdn,nod_crdn,fac_nod);
    j_bef(fac_mid_idx)=q_sp*vel_aft(3)/fac_area(fac_mid_idx)*n_vec_sign(fac_mid_idx);
end

end