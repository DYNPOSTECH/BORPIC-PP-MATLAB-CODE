function [...
    N_0,N_1,N_2,DT,...    
    fac_edg,fac_nod,...
    edg_nod,...
    edg_length,...
    nod_crdn]=FEM_2D_Mesh_Getter_gmsh(nod_crdn,fac_nod,N_0,N_2)

DT=triangulation(fac_nod,nod_crdn(:,1),nod_crdn(:,2));

% DT
% figure;
% trimesh(DT,nod_crdn(:,1),nod_crdn(:,2));%,'facecolor','b','FaceAlpha',0.3);

edg_nod=zeros(3*N_2,2);
cnt_1=0;
loc_edg_nod=[1,2;1,3;2,3];
for i=1:N_2
    fac_nod(i,:)=sort(fac_nod(i,:));        
    loc_nod_idx=fac_nod(i,:);    
    edg_nod(cnt_1+1:cnt_1+3,:)=loc_nod_idx(loc_edg_nod);
    cnt_1=cnt_1+3;        
end
[edg_nod,~,edg_label]=unique(edg_nod,'rows');
N_1=size(edg_nod,1);

fac_edg=zeros(N_2,3);
cnt_1=0;
for i=1:N_2
    fac_edg(i,:)=edg_label(cnt_1+1:cnt_1+3);    
    cnt_1=cnt_1+3;        
end

edg_length=zeros(N_1,1);
for i=1:N_1
    edg_crdn_1=nod_crdn(edg_nod(i,1),:);
    edg_crdn_2=nod_crdn(edg_nod(i,2),:);    
    edg_length(i)=norm(edg_crdn_1-edg_crdn_2);
end

end