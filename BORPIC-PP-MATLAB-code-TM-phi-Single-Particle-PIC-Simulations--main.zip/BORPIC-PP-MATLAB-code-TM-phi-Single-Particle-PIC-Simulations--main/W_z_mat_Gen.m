function W_z_mat_sp_mat = W_z_mat_Gen(cond_set,N_2,del_t,mu_r)

[eps_0,mu_0,eta_0,c]=Constants_func();

tau=2/del_t;

W_z_mat_sp_i=zeros(N_2,1);
W_z_mat_sp_j=zeros(N_2,1);
W_z_mat_sp_v=zeros(N_2,1);
cnt_mu=0;
for i=1:N_2       
    
    r_0 = cond_set(i,1)*cond_set(i,2);
    r_1 = eps_0*(cond_set(i,1) + cond_set(i,2));
    r_2 = eps_0^2;

    q_0 = 0;
    q_1 = 0;
    q_2 = eps_0^2/mu_r(i);
    
    w_z = (tau^2*q_2)/(r_0 + tau*r_1 + tau^2*r_2);

    cnt_mu=cnt_mu+1;
    W_z_mat_sp_i(cnt_mu)=i;
    W_z_mat_sp_j(cnt_mu)=i;
    W_z_mat_sp_v(cnt_mu)=w_z;
    
end
W_z_mat_sp_i(cnt_mu+1:end)=[];
W_z_mat_sp_j(cnt_mu+1:end)=[];
W_z_mat_sp_v(cnt_mu+1:end)=[];

W_z_mat_sp_mat=sparse(W_z_mat_sp_i,W_z_mat_sp_j,W_z_mat_sp_v,N_2,N_2);
    
end
