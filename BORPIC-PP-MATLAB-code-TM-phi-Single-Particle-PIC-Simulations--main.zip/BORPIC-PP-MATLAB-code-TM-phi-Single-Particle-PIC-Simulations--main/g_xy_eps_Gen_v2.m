function g_xy_eps_sp = g_xy_eps_Gen_v2(...
    N_1_pml,edg_pml_fac_up_down,up_down_opt,x_y_opt,del_t,...
    d_dof_sp_set,e_dof_sp_set,cond_set,eps_r)

[eps_0,mu_0,eta_0,c]=Constants_func();

if x_y_opt==1
    opos_x_y_opt=2;
elseif x_y_opt==2
    opos_x_y_opt=1;
end

r_eps_set = zeros(N_1_pml,1);
q_eps_set = zeros(N_1_pml,1);

fac_idx=edg_pml_fac_up_down(:,up_down_opt);
no_fac_edg_idx=find(fac_idx==0);
fac_idx(no_fac_edg_idx)=1;

r_eps_set(:,0+1) = cond_set(fac_idx,x_y_opt);
r_eps_set(:,1+1) = eps_0;

q_eps_set(:,0+1) = cond_set(fac_idx,opos_x_y_opt).*eps_r(fac_idx);
q_eps_set(:,1+1) = eps_0*eps_r(fac_idx);

[u_eps_set,v_eps_set,~] = QR_UVW_eps_Converter(q_eps_set,r_eps_set,del_t,N_1_pml);

g_xy_eps = sum(d_dof_sp_set.*u_eps_set,2) - sum(e_dof_sp_set.*v_eps_set,2);
g_xy_eps(no_fac_edg_idx)=0;
g_xy_eps_sp = sparse(g_xy_eps);

% for i=1:N_1
%     fac_idx=edg_pml_fac_up_down(i,up_down_opt);
%     r_eps_set=zeros(2,1);
%     q_eps_set=zeros(2,1);
%     if fac_idx==0        
%     else    
%         r_eps_set(0+1) = cond_set(fac_idx,x_y_opt);
%         r_eps_set(1+1) = eps_0;
% 
%         q_eps_set(0+1) = cond_set(fac_idx,opos_x_y_opt)*eps_r(fac_idx);
%         q_eps_set(1+1) = eps_0*eps_r(fac_idx);        
% 
%         [u_eps_set,v_eps_set,~] = QR_UVW_eps_Converter(q_eps_set,r_eps_set,del_t,N_2);
%         
%         g_xy_eps(i) = ...
%             u_eps_set(0+1)*d_dof_sp_set(i,0+1) - v_eps_set(0+1)*e_dof_sp_set(i,0+1) +...
%             u_eps_set(1+1)*d_dof_sp_set(i,1+1) - v_eps_set(1+1)*e_dof_sp_set(i,1+1);
%     end
% end
% g_xy_eps_sp=sparse(g_xy_eps);

end