clear all; clc; close all;

%% Constants
[eps_0,mu_0,eta_0,c]=Constants_func();

%% SPAI order
order_p = 3;
part_ref_opt=1;

%% Line antenna profile
z_st_ant = -0.45;
z_en_ant = +0.45;
rho_ant = 0.75;

%% Input parameter setup
% particle information initialization
[pos_bef,vel_bef,q_sp,m_sp]=Particle_Initialization();
pos_bef_0 = pos_bef;
vel_bef_0 = vel_bef;

tot_charge = q_sp;

particle_shape_opt=1;
if particle_shape_opt==1
    pat_l = 0.01;%25;
    q_sp = tot_charge / (2*pat_l)^2;
elseif particle_shape_opt==0    
end


% time discretization
del_t=0.001/c;
N_t=30001;

% geometry
z_min = -.5;
z_max =  .5;
r_min = 0;
r_max = 1.;
pml_l = 0.025;
pml_N = 5;
pml_length_tot = pml_l*pml_N;

% pml parameter
PML_ll_x_st=z_min;
PML_rr_x_st=z_max;
PML_dd_y_st=r_min;
PML_uu_y_st=r_max;

PML_N=pml_N;
PML_h=pml_l;
PML_L=pml_length_tot;

L_x_tot = z_max - z_min;
L_y_tot = r_max + pml_length_tot;

pml_order=2;
cond_0=0.75;

% gaussian quadrature parameter
GC_order_p=2;

%% Mesh information getter
disp('- Reading mesh files...') 
tic
load nod_crdn.txt;
load fac_nod.txt;
nod_crdn=nod_crdn(:,2:3);
fac_org_idx=fac_nod(:,1);
fac_nod=fac_nod(:,2:4);
fac_nod=sort(fac_nod,2);
N_0=size(nod_crdn,1);
N_2=size(fac_nod,1);
toc

disp('- Mesh information getter...') 
tic
[...
    N_0,N_1,N_2,DT,...    
    fac_edg,fac_nod,...
    edg_nod,...
    edg_length,...
    nod_crdn]=FEM_2D_Mesh_Getter_gmsh(nod_crdn,fac_nod,N_0,N_2);
toc

disp('- X_mat, G_mat, gradient of barycentric coordinate s getter...')
tic
[X_mat,G_mat,fac_area]=FEM_2D_X_G_Mat_Gen(N_2,fac_nod,nod_crdn);
toc

% normal vector sign of W2 form
n_vec_sign = W2_Normal_Vector_Sign(G_mat,N_2);

% center coordinates of element, face, and edges
[fac_cent_crdn,edg_cent_crdn]=Center_2D_coordinate(...
    N_2,N_1,nod_crdn,fac_nod,edg_nod);
disp(append('- DoFs (# of edges) = ',num2str(N_1)));

% mesh plot
edg_x=[nod_crdn(edg_nod(:,1),1),nod_crdn(edg_nod(:,2),1)]';
edg_y=[nod_crdn(edg_nod(:,1),2),nod_crdn(edg_nod(:,2),2)]';
uu=edg_x(2,:)-edg_x(1,:);
vv=edg_y(2,:)-edg_y(1,:);

% PBC edges finder
[rr,~]=find(edg_cent_crdn(:,1)==z_min);% & edg_cent_crdn(:,2)<= r_max );
pbc_lef_edg_idx=rr;
[rr,~]=find(edg_cent_crdn(:,1)==z_max);% & edg_cent_crdn(:,2)<= r_max );
pbc_rig_edg_idx=rr;
pbc_edg_idx=[pbc_lef_edg_idx,pbc_rig_edg_idx];
N_pbc_edg = length(pbc_rig_edg_idx);

% boundary edges
bc_edg=zeros(N_1,1);

particle_r_boundary = r_max*1.0;
if part_ref_opt==0
    [rr,~]=find(edg_cent_crdn(:,2)==r_max);
elseif part_ref_opt==1
    [rr,~]=find(edg_cent_crdn(:,2)==L_y_tot);
end
top_edg_idx=rr;
[rr,~]=find(edg_cent_crdn(:,2)==r_min);
bot_edg_idx=rr;
bc_edg(bot_edg_idx)=1;
bc_edg(top_edg_idx)=2;
bc_edg(pbc_lef_edg_idx)=3;
bc_edg(pbc_rig_edg_idx)=4;

fac_edg_org = fac_edg;
for ii=1:N_pbc_edg
    rig_idx = pbc_rig_edg_idx(ii);
    lef_idx = pbc_lef_edg_idx(ii);
    for i=1:N_2
        [det,loc]=ismember(rig_idx,fac_edg_org(i,:));
        if det==1
            fac_edg(i,loc) = lef_idx;
        end
    end
end
% edg_nod(pbc_rig_edg_idx,:)=[];
% N_1=length(edg_nod(:,1));

% stop

%% Perfectly Matched Layers
[cond_set,~]=...
    PML_setup_BOR(N_2,...
    PML_ll_x_st,PML_rr_x_st,PML_dd_y_st,PML_uu_y_st,...
    cond_0,PML_h,PML_L,pml_order,fac_cent_crdn);

fac_pml_idx = sum(cond_set,2);
rr=find(fac_pml_idx~=0);
fac_pml_idx=rr;
N_2_pml = length(fac_pml_idx);

% figure;
% subplot(211)
% plot3(fac_cent_crdn(:,1),fac_cent_crdn(:,2),cond_set(:,1),'or');hold on;
% subplot(212)
% plot3(fac_cent_crdn(:,1),fac_cent_crdn(:,2),cond_set(:,2),'ob');hold on;
% stop

%% --------------------------------------------------------------------- %%

%% FEM system matrix
disp('Incidence matrix');
tic
inc_sp_mat_org=Incidence_Mat_Gen_2D(N_2,N_1,fac_edg_org);
inc_sp_mat=Incidence_Mat_Gen_2D(N_2,N_1,fac_edg);
dual_inc_sp_mat_org=transpose(inc_sp_mat_org);
dual_inc_sp_mat=transpose(inc_sp_mat);
toc

%% PML related L and W matrix generation
tic
edg_fac_up_dn = zeros(N_1,2);
disp('- finding edge-face up dn ...');
pbc_rig_idx_check = zeros(N_1,1);
for i=1:N_1    
    nz_col = find( dual_inc_sp_mat(i,:)~=0 );
    if length(nz_col)==2
        edg_fac_up_dn(i,:)=nz_col;
    elseif length(nz_col)==1
        edg_fac_up_dn(i,1)=nz_col;
    else        
        pbc_rig_idx_check(i) = 1;
    end    
end

tic
disp('-finding index of edges that touch faces of PML...');
edg_pml_idx = zeros(N_2*3,1);
cnt_st=1;
for i=1:N_2_pml
    cnt_end=cnt_st+2;
    edg_pml_idx(cnt_st:cnt_end)=fac_edg(fac_pml_idx(i),:);
%     edg_pml_idx(cnt_st:cnt_end)=fac_edg(i,:);
    cnt_st=cnt_end+1;
end
edg_pml_idx=unique(edg_pml_idx);
edg_pml_idx(edg_pml_idx==0)=[];
N_1_pml = length(edg_pml_idx);
edg_pml_fac_up_dn = edg_fac_up_dn(edg_pml_idx,:);
toc

% L matrix generation
x_y_opt=1; up_dn_opt=1; 
L_mat_sp_x_up    = L_mat_Gen(edg_fac_up_dn,N_1,N_2,up_dn_opt,x_y_opt,G_mat,fac_area,fac_edg);
x_y_opt=1; up_dn_opt=2; 
L_mat_sp_x_dn  = L_mat_Gen(edg_fac_up_dn,N_1,N_2,up_dn_opt,x_y_opt,G_mat,fac_area,fac_edg);
x_y_opt=2; up_dn_opt=1; 
L_mat_sp_y_up    = L_mat_Gen(edg_fac_up_dn,N_1,N_2,up_dn_opt,x_y_opt,G_mat,fac_area,fac_edg);
x_y_opt=2; up_dn_opt=2; 
L_mat_sp_y_dn  = L_mat_Gen(edg_fac_up_dn,N_1,N_2,up_dn_opt,x_y_opt,G_mat,fac_area,fac_edg);

L_mat_sp = L_mat_sp_x_up + L_mat_sp_x_dn + L_mat_sp_y_up + L_mat_sp_y_dn;

% L_mat_Sanity_Check = L_Mat_Sanity_Check(N_1,N_2,fac_edg,fac_area,G_mat);
% Res_mat = L_mat_Sanity_Check-L_mat_sp;
% sum(sum(abs(L_mat_sp).^2))
% sum(sum(abs(L_mat_Sanity_Check).^2))
% sum(sum(abs(Res_mat).^2))


%% W matrix generation
% relative permittivity and permeability encoding \rho
% % % eps_r = fac_cent_crdn(:,2)*eps_0;
% % % mu_r = mu_0./fac_cent_crdn(:,2);
eps_r_tm_phi = eps_0./fac_cent_crdn(:,2);
mu_r_tm_phi = mu_0*fac_cent_crdn(:,2);

x_y_opt = 1;up_dn_opt = 1;
W_mat_sp_x_up    = W_mat_Gen(cond_set,mu_r_tm_phi,edg_fac_up_dn,N_1,N_2,up_dn_opt,x_y_opt,G_mat,fac_area,fac_edg,del_t);
x_y_opt = 1;up_dn_opt = 2;
W_mat_sp_x_dn  = W_mat_Gen(cond_set,mu_r_tm_phi,edg_fac_up_dn,N_1,N_2,up_dn_opt,x_y_opt,G_mat,fac_area,fac_edg,del_t);
x_y_opt = 2;up_dn_opt = 1;
W_mat_sp_y_up    = W_mat_Gen(cond_set,mu_r_tm_phi,edg_fac_up_dn,N_1,N_2,up_dn_opt,x_y_opt,G_mat,fac_area,fac_edg,del_t);
x_y_opt = 2;up_dn_opt = 2;
W_mat_sp_y_dn  = W_mat_Gen(cond_set,mu_r_tm_phi,edg_fac_up_dn,N_1,N_2,up_dn_opt,x_y_opt,G_mat,fac_area,fac_edg,del_t);

WL_x_up      = W_mat_sp_x_up*L_mat_sp_x_up;
WL_x_dn    = W_mat_sp_x_dn*L_mat_sp_x_dn;
WL_y_up      = W_mat_sp_y_up*L_mat_sp_y_up;
WL_y_dn    = W_mat_sp_y_dn*L_mat_sp_y_dn;

A_eps_mat_sp =  WL_x_up + WL_x_dn + WL_y_up + WL_y_dn;
A_eps_mat_sp(pbc_rig_edg_idx,pbc_rig_edg_idx) = eye(N_pbc_edg);

% SPAI
[r_SP,c_SP]=find(A_eps_mat_sp~=0);
N_nz=length(r_SP);
SP_A_eps_mat_sp = sparse(r_SP,c_SP,ones(N_nz,1));

for i=1:order_p-1
    SP_A_eps_mat_sp = SP_A_eps_mat_sp*SP_A_eps_mat_sp;
end
[r_SP_final,c_SP_final]=find(SP_A_eps_mat_sp~=0);
N_nz_final=length(r_SP_final);

I_mat_sp = speye(N_1);

disp('SPAI...')
tic
A_eps_inv_SPAI_mat_sp=SPAI(A_eps_mat_sp, SP_A_eps_mat_sp, I_mat_sp, N_1);
toc
A_eps_inv_SPAI_mat_sp(pbc_rig_edg_idx,pbc_rig_edg_idx) = 0;


%% Mu system matrix
L_z_mat_sp_mat = L_z_mat_Gen(N_2,fac_area);
W_z_mat_sp_mat = W_z_mat_Gen(cond_set,N_2,del_t,eps_r_tm_phi);
A_mu_inv_mat_sp = W_z_mat_sp_mat*L_z_mat_sp_mat;

%% --------------------------------------------------------------------- %%

%% dynamical variables for time update
new_d_new_bef_0_sp=sparse(N_2,1); new_d_new_bef_1_sp=sparse(N_2,1); new_d_new_bef_2_sp=sparse(N_2,1);
new_d_new_aft_0_sp=sparse(N_2,1); new_d_new_aft_1_sp=sparse(N_2,1); new_d_new_aft_2_sp=sparse(N_2,1);
new_e_new_bef_0_sp=sparse(N_2,1); new_e_new_bef_1_sp=sparse(N_2,1); new_e_new_bef_2_sp=sparse(N_2,1);

new_e_new_aft_0_sp=sparse(N_2,1); new_e_new_aft_1_sp=sparse(N_2,1); new_e_new_aft_2_sp=sparse(N_2,1);
new_b_new_bef_0_sp=sparse(N_1,1); new_b_new_aft_0_sp=sparse(N_1,1);

new_b_new_bef_0_x_up_sp = sparse(N_1_pml,1); new_b_new_bef_0_x_dn_sp = sparse(N_1_pml,1);
new_b_new_bef_0_y_up_sp = sparse(N_1_pml,1); new_b_new_bef_0_y_dn_sp = sparse(N_1_pml,1);
new_b_new_bef_1_x_up_sp = sparse(N_1_pml,1); new_b_new_bef_1_x_dn_sp = sparse(N_1_pml,1);
new_b_new_bef_1_y_up_sp = sparse(N_1_pml,1); new_b_new_bef_1_y_dn_sp = sparse(N_1_pml,1);

new_h_new_bef_0_sp=sparse(N_1,1); new_h_new_aft_0_sp=sparse(N_1,1);

new_h_new_bef_0_x_up_sp = sparse(N_1_pml,1); new_h_new_bef_0_x_dn_sp = sparse(N_1_pml,1);
new_h_new_bef_0_y_up_sp = sparse(N_1_pml,1); new_h_new_bef_0_y_dn_sp = sparse(N_1_pml,1);
new_h_new_bef_1_x_up_sp = sparse(N_1_pml,1); new_h_new_bef_1_x_dn_sp = sparse(N_1_pml,1);
new_h_new_bef_1_y_up_sp = sparse(N_1_pml,1); new_h_new_bef_1_y_dn_sp = sparse(N_1_pml,1);

% u v parameters
x_y_opt = 1;up_dn_opt = 1;
[u_eps_x_up_set,v_eps_x_up_set] = ...
    UV_eps_set(N_1_pml,edg_pml_fac_up_dn,up_dn_opt,x_y_opt,del_t,cond_set,mu_r_tm_phi);
x_y_opt = 1;up_dn_opt = 2;
[u_eps_x_dn_set,v_eps_x_dn_set] = ...
    UV_eps_set(N_1_pml,edg_pml_fac_up_dn,up_dn_opt,x_y_opt,del_t,cond_set,mu_r_tm_phi);
x_y_opt = 2;up_dn_opt = 1;
[u_eps_y_up_set,v_eps_y_up_set] = ...
    UV_eps_set(N_1_pml,edg_pml_fac_up_dn,up_dn_opt,x_y_opt,del_t,cond_set,mu_r_tm_phi);
x_y_opt = 2;up_dn_opt = 2;
[u_eps_y_dn_set,v_eps_y_dn_set] = ...
    UV_eps_set(N_1_pml,edg_pml_fac_up_dn,up_dn_opt,x_y_opt,del_t,cond_set,mu_r_tm_phi);

% --------------------------------------------------------------------- %
% --------------------------------------------------------------------- %
% ---------------------------Time update------------------------------- %
% --------------------------------------------------------------------- %
% --------------------------------------------------------------------- %
j_bef_sp=sparse(N_2,1);
for ts = 1:N_t
    if mod(ts,10)==1
        disp(append('time index = ',num2str(ts)))
    end    
    
    if ts>1
        % dynamical variable update
        new_d_new_bef_0_sp = new_d_new_aft_0_sp; new_d_new_bef_1_sp = new_d_new_aft_1_sp; new_d_new_bef_2_sp = new_d_new_aft_2_sp;
        new_e_new_bef_0_sp = new_e_new_aft_0_sp; new_e_new_bef_1_sp = new_e_new_aft_1_sp; new_e_new_bef_2_sp = new_e_new_aft_2_sp;
        new_b_new_bef_0_sp = new_b_new_aft_0_sp;       

        new_b_new_bef_0_x_up_sp = new_b_new_aft_0_x_up_sp; new_b_new_bef_0_x_dn_sp = new_b_new_aft_0_x_dn_sp;
        new_b_new_bef_0_y_up_sp = new_b_new_aft_0_y_up_sp; new_b_new_bef_0_y_dn_sp = new_b_new_aft_0_y_dn_sp;

        new_b_new_bef_1_x_up_sp = new_b_new_aft_1_x_up_sp; new_b_new_bef_1_x_dn_sp = new_b_new_aft_1_x_dn_sp;
        new_b_new_bef_1_y_up_sp = new_b_new_aft_1_y_up_sp; new_b_new_bef_1_y_dn_sp = new_b_new_aft_1_y_dn_sp;

        new_h_new_bef_0_sp = new_h_new_aft_0_sp;

        new_h_new_bef_0_x_up_sp = new_h_new_aft_0_x_up_sp; new_h_new_bef_0_x_dn_sp = new_h_new_aft_0_x_dn_sp;
        new_h_new_bef_0_y_up_sp = new_h_new_aft_0_y_up_sp; new_h_new_bef_0_y_dn_sp = new_h_new_aft_0_y_dn_sp;
        
        new_h_new_bef_1_x_up_sp = new_h_new_aft_1_x_up_sp; new_h_new_bef_1_x_dn_sp = new_h_new_aft_1_x_dn_sp;
        new_h_new_bef_1_y_up_sp = new_h_new_aft_1_y_up_sp; new_h_new_bef_1_y_dn_sp = new_h_new_aft_1_y_dn_sp;

        pos_bef = pos_aft; vel_bef = vel_aft;
    end           

    % Discrete Ampere's law for new_d_new_aft
    new_d_new_aft_0_sp = new_d_new_bef_0_sp + del_t*inc_sp_mat*new_h_new_bef_0_sp - del_t*j_bef_sp;

    new_d_new_aft_1_sp = -new_d_new_bef_1_sp + 2/del_t*( new_d_new_aft_0_sp - new_d_new_bef_0_sp );
    new_d_new_aft_2_sp = -new_d_new_bef_2_sp + 2/del_t*( new_d_new_aft_1_sp - new_d_new_bef_1_sp );    
       
    % PML mu part
    b_dof_sp_set=[new_d_new_bef_0_sp(fac_pml_idx),new_d_new_bef_1_sp(fac_pml_idx),new_d_new_bef_2_sp(fac_pml_idx)];
    b_dof_sp_set = L_z_mat_sp_mat(fac_pml_idx,fac_pml_idx)*b_dof_sp_set;
    h_dof_sp_set=[new_e_new_bef_0_sp(fac_pml_idx),new_e_new_bef_1_sp(fac_pml_idx),new_e_new_bef_2_sp(fac_pml_idx)];   
    
    g_mu_bef = g_z_bef_Gen_v2(N_2_pml,del_t,b_dof_sp_set,h_dof_sp_set,cond_set,eps_r_tm_phi,fac_pml_idx);
    g_mu_bef_sp = sparse(fac_pml_idx,ones(N_2_pml,1),g_mu_bef,N_2,1);
    
    % Converting new_d_new_aft to new_e_new_aft
    new_e_new_aft_0_sp = A_mu_inv_mat_sp*new_d_new_aft_0_sp + g_mu_bef_sp;
    
    new_e_new_aft_1_sp = -new_e_new_bef_1_sp + 2/del_t*( new_e_new_aft_0_sp - new_e_new_bef_0_sp );
    new_e_new_aft_2_sp = -new_e_new_bef_2_sp + 2/del_t*( new_e_new_aft_1_sp - new_e_new_bef_1_sp );
       
    % current initialization
    j_bef = zeros(N_2,1);    
    % particle loop
    for p_idx = 1
        % Gather
        e_dof = new_h_new_bef_0_sp;
        b_dof = (new_d_new_bef_0_sp+new_d_new_aft_0_sp)/2;
        fac_idx = Find_Fac(pos_bef,fac_cent_crdn,nod_crdn,fac_nod);
        E_field_val = E_field_Interpolation_2D(pos_bef,fac_idx,G_mat,e_dof,fac_edg);
        B_field_val = B_field_Interpolation_2D(b_dof,fac_idx,fac_area,fac_nod,nod_crdn);        
        
        % Push
        LF_fac=q_sp*del_t/m_sp;

        N_mat = [1,-LF_fac/2*B_field_val,0;LF_fac/2*B_field_val,1,0;0,0,1];
        N_mat_inv = inv(N_mat);
        N_mat_trs = transpose(N_mat);

        E_field_gather = [E_field_val;0];
        vel_aft = N_mat_inv*(N_mat_trs*vel_bef + LF_fac*E_field_gather);
        pos_aft = pos_bef + del_t*vel_aft(1:2);
        pos_mid = (pos_bef + pos_aft)/2;               


        if pos_aft(2) > particle_r_boundary
            1
            Two_Trajectory_Option = 1;  
            m_crs_bc = (pos_aft(2)-pos_bef(2))/(pos_aft(1)-pos_bef(1));
            pos_crs_bc=zeros(2,1);
            pos_crs_bc(2) = particle_r_boundary;
            pos_crs_bc(1) = (pos_crs_bc(2)-pos_bef(2))/m_crs_bc+pos_bef(1);            
            
            pos_bef_1=pos_bef;
            pos_aft_1=pos_crs_bc;
            pos_mid_1 = (pos_bef_1+pos_aft_1)/2;            
            vel_aft_1 = vel_aft;

            pos_bef_2=pos_crs_bc;
            pos_aft_2=pos_aft;            
            pos_aft_2(2) = pos_crs_bc(2) - (pos_aft(2)-pos_crs_bc(2));            
            pos_mid_2 = (pos_bef_2+pos_aft_2)/2;                        
            vel_aft_2 = vel_aft;
            vel_aft_2(2) = -vel_aft_2(2);
            
            pos_aft = pos_aft_2;
            vel_aft = vel_aft_2;
        else 
            Two_Trajectory_Option = 0;
        end    

        % Scatter
        if Two_Trajectory_Option == 1
            j_bef=Scatter_TM_Phi(pos_mid_1,fac_cent_crdn,nod_crdn,fac_nod,pat_l,j_bef,q_sp,vel_aft_1,fac_area,n_vec_sign,particle_shape_opt);
            j_bef=Scatter_TM_Phi(pos_mid_2,fac_cent_crdn,nod_crdn,fac_nod,pat_l,j_bef,q_sp,vel_aft_2,fac_area,n_vec_sign,particle_shape_opt);
        elseif Two_Trajectory_Option ==0
            j_bef=Scatter_TM_Phi(pos_mid,fac_cent_crdn,nod_crdn,fac_nod,pat_l,j_bef,q_sp,vel_aft,fac_area,n_vec_sign,particle_shape_opt);
        end

    end
    
    j_bef_sp=sparse(j_bef);

    % Discrete Faraday's law for new_b_new_aft
    new_b_new_aft_0_sp = new_b_new_bef_0_sp - del_t*dual_inc_sp_mat*new_e_new_aft_0_sp;% - del_t*j_bef_sp;
    
    % PML related eps part
    d_dof_sp_set = [new_b_new_bef_0_x_up_sp,new_b_new_bef_1_x_up_sp];
    e_dof_sp_set = [new_h_new_bef_0_x_up_sp,new_h_new_bef_1_x_up_sp];    
    g_eps_x_up = g_xy_eps_Gen_v3(u_eps_x_up_set,v_eps_x_up_set,d_dof_sp_set,e_dof_sp_set);

    d_dof_sp_set = [new_b_new_bef_0_x_dn_sp,new_b_new_bef_1_x_dn_sp];
    e_dof_sp_set = [new_h_new_bef_0_x_dn_sp,new_h_new_bef_1_x_dn_sp];
    g_eps_x_dn = g_xy_eps_Gen_v3(u_eps_x_dn_set,v_eps_x_dn_set,d_dof_sp_set,e_dof_sp_set);

    d_dof_sp_set = [new_b_new_bef_0_y_up_sp,new_b_new_bef_1_y_up_sp];
    e_dof_sp_set = [new_h_new_bef_0_y_up_sp,new_h_new_bef_1_y_up_sp];    
    g_eps_y_up = g_xy_eps_Gen_v3(u_eps_y_up_set,v_eps_y_up_set,d_dof_sp_set,e_dof_sp_set);

    d_dof_sp_set = [new_b_new_bef_0_y_dn_sp,new_b_new_bef_1_y_dn_sp];
    e_dof_sp_set = [new_h_new_bef_0_y_dn_sp,new_h_new_bef_1_y_dn_sp];    
    g_eps_y_dn = g_xy_eps_Gen_v3(u_eps_y_dn_set,v_eps_y_dn_set,d_dof_sp_set,e_dof_sp_set);
    
    g_eps_bef = g_eps_x_up + g_eps_x_dn + g_eps_y_up + g_eps_y_dn;
    g_eps_bef_sp = sparse(edg_pml_idx,ones(N_1_pml,1),g_eps_bef,N_1,1);
    
    % Converting new_b_new_aft to new_h_new_aft
    new_h_new_aft_0_sp = A_eps_inv_SPAI_mat_sp*(new_b_new_aft_0_sp - g_eps_bef_sp);
    
    % update variables
    new_h_new_aft_0_x_up_sp = L_mat_sp_x_up(edg_pml_idx,edg_pml_idx)*new_h_new_aft_0_sp(edg_pml_idx);
    new_h_new_aft_0_x_dn_sp = L_mat_sp_x_dn(edg_pml_idx,edg_pml_idx)*new_h_new_aft_0_sp(edg_pml_idx);
    new_h_new_aft_0_y_up_sp = L_mat_sp_y_up(edg_pml_idx,edg_pml_idx)*new_h_new_aft_0_sp(edg_pml_idx);
    new_h_new_aft_0_y_dn_sp = L_mat_sp_y_dn(edg_pml_idx,edg_pml_idx)*new_h_new_aft_0_sp(edg_pml_idx);
    
    new_b_new_aft_0_x_up_sp = W_mat_sp_x_up(edg_pml_idx,edg_pml_idx)*new_h_new_aft_0_x_up_sp + g_eps_x_up;
    new_b_new_aft_0_x_dn_sp = W_mat_sp_x_dn(edg_pml_idx,edg_pml_idx)*new_h_new_aft_0_x_dn_sp + g_eps_x_dn;
    new_b_new_aft_0_y_up_sp = W_mat_sp_y_up(edg_pml_idx,edg_pml_idx)*new_h_new_aft_0_y_up_sp + g_eps_y_up;
    new_b_new_aft_0_y_dn_sp = W_mat_sp_y_dn(edg_pml_idx,edg_pml_idx)*new_h_new_aft_0_y_dn_sp + g_eps_y_dn;

    new_h_new_aft_1_x_up_sp = -new_h_new_bef_1_x_up_sp + 2/del_t*( new_h_new_aft_0_x_up_sp - new_h_new_bef_0_x_up_sp );
    new_h_new_aft_1_x_dn_sp = -new_h_new_bef_1_x_dn_sp + 2/del_t*( new_h_new_aft_0_x_dn_sp - new_h_new_bef_0_x_dn_sp );
    new_h_new_aft_1_y_up_sp = -new_h_new_bef_1_y_up_sp + 2/del_t*( new_h_new_aft_0_y_up_sp - new_h_new_bef_0_y_up_sp );
    new_h_new_aft_1_y_dn_sp = -new_h_new_bef_1_y_dn_sp + 2/del_t*( new_h_new_aft_0_y_dn_sp - new_h_new_bef_0_y_dn_sp );
    
    new_b_new_aft_1_x_up_sp = -new_b_new_bef_1_x_up_sp + 2/del_t*( new_b_new_aft_0_x_up_sp - new_b_new_bef_0_x_up_sp );
    new_b_new_aft_1_x_dn_sp = -new_b_new_bef_1_x_dn_sp + 2/del_t*( new_b_new_aft_0_x_dn_sp - new_b_new_bef_0_x_dn_sp );
    new_b_new_aft_1_y_up_sp = -new_b_new_bef_1_y_up_sp + 2/del_t*( new_b_new_aft_0_y_up_sp - new_b_new_bef_0_y_up_sp );
    new_b_new_aft_1_y_dn_sp = -new_b_new_bef_1_y_dn_sp + 2/del_t*( new_b_new_aft_0_y_dn_sp - new_b_new_bef_0_y_dn_sp );
    T_ed_upd = toc;

    if mod(ts,500)==1
        close all;
        e_interp_vec=new_h_new_aft_0_sp;              
         
        N_x_interp=150;        N_y_interp=150;
        
        L_x_st=PML_ll_x_st;
        L_x_end=PML_rr_x_st;
        L_y_st=PML_dd_y_st;
        L_y_end=PML_uu_y_st+pml_length_tot;
        
        [xq,yq,Scat_E_x,Scat_E_y]=...
            Scattered_field_interpolation_3_2D(...
            N_x_interp,N_y_interp,...
            L_x_st,L_x_end,L_y_st,L_y_end,...
            DT,G_mat,e_interp_vec,fac_edg);
        
        tot_E_field_x=Scat_E_x;
        tot_E_field_y=Scat_E_y;
        
        tot_E_field_amp=sqrt( abs(tot_E_field_x).^2+abs(tot_E_field_y).^2 );
        
        close all;
        figure;
        surf(xq,yq,tot_E_field_amp,'edgecolor','none');hold on;
        plot3([z_min z_max],[r_max r_max],[100 100],'--r','linewidth',1);
        axis equal;
        view([0 90]);
        xlim([z_min z_max]);
        ylim([0 L_y_tot]);
%         colorbar;
        colormap(hot);
        caxis([0 0.03]);

        N_x_interp=40;        N_y_interp=40;
        
        L_x_st=PML_ll_x_st;
        L_x_end=PML_rr_x_st;
        L_y_st=PML_dd_y_st;
        L_y_end=PML_uu_y_st+pml_length_tot;
        
        [xq,yq,Scat_E_x,Scat_E_y]=...
            Scattered_field_interpolation_3_2D(...
            N_x_interp,N_y_interp,...
            L_x_st,L_x_end,L_y_st,L_y_end,...
            DT,G_mat,e_interp_vec,fac_edg);
        
        tot_E_field_x=Scat_E_x;
        tot_E_field_y=Scat_E_y;

        sc=0.4;
        zq = ones(size(xq))*1e10;
        quiver3(xq,yq,zq,tot_E_field_x/sc,tot_E_field_y/sc,zeros(size(xq)),0,'g');hold on;
        plot(pos_bef_0(1),pos_bef_0(2),'ob','markerfacecolor','b');
        plot(pos_aft(1),pos_aft(2),'squareb','markerfacecolor','b');
        plot3([z_min z_max],[r_max r_max],[100 100],'-r','linewidth',1);
        plot3([z_min z_max],[particle_r_boundary particle_r_boundary],[100 100],'--y','linewidth',1);
        axis equal;
        xlabel('z [m]');        ylabel('\rho [m]');
        titlename = append('Time step = ',num2str(ts));
        set(gca,'fontsize',13);
        savename = append('H_field_amp_BOR_ts=',num2str(ts),'.fig');
        saveas(gca,savename);
    
    end


% % %     if mod(ts,10)==1
% % % 
% % %         e_interp_vec=new_h_new_aft_0_sp;  
% % %         
% % %         N_x_interp=150;        N_y_interp=150;
% % %         
% % %         L_x_st=PML_ll_x_st;
% % %         L_x_end=PML_rr_x_st;
% % %         L_y_st=PML_dd_y_st;
% % %         L_y_end=PML_uu_y_st+pml_length_tot;
% % %         
% % %         [xq,yq,Scat_E_x,Scat_E_y]=...
% % %             Scattered_field_interpolation_3_2D(...
% % %             N_x_interp,N_y_interp,...
% % %             L_x_st,L_x_end,L_y_st,L_y_end,...
% % %             DT,G_mat,e_interp_vec,fac_edg);
% % %         
% % %         tot_E_field_x=Scat_E_x;
% % %         tot_E_field_y=Scat_E_y;
% % %         
% % %         tot_E_field_amp=sqrt( abs(tot_E_field_x).^2+abs(tot_E_field_y).^2 );
% % %         
% % %         close all;
% % %         figure;
% % %         surf(xq,yq,tot_E_field_amp,'edgecolor','none');hold on;
% % % %         surf(xq,yq,tot_E_field_x,'edgecolor','none');hold on;
% % %         plot3([z_min z_max],[r_max r_max],[100 100],'--r','linewidth',1);
% % % %         plot3(pos_aft(1),pos_aft(2),100,'or','markerfacecolor','r','linewidth',1);
% % %         axis equal;
% % %         view([0 90]);
% % %         xlim([z_min z_max]);
% % %         ylim([0 L_y_tot]);
% % %         colorbar;
% % %         colormap(redblue);
% % %         caxis([-10000 10000]);
% % % %         caxis([-2.5 2.5]/2/2/2);
% % % % % %         caxis([-100 100]);
% % % 
% % %         N_x_interp=50;        N_y_interp=50;
% % %         
% % %         L_x_st=PML_ll_x_st;
% % %         L_x_end=PML_rr_x_st;
% % %         L_y_st=PML_dd_y_st;
% % %         L_y_end=PML_uu_y_st+pml_length_tot;
% % %         
% % %         [xq,yq,Scat_E_x,Scat_E_y]=...
% % %             Scattered_field_interpolation_3_2D(...
% % %             N_x_interp,N_y_interp,...
% % %             L_x_st,L_x_end,L_y_st,L_y_end,...
% % %             DT,G_mat,e_interp_vec,fac_edg);
% % %         
% % %         tot_E_field_x=Scat_E_x;
% % %         tot_E_field_y=Scat_E_y;
% % % 
% % %         sc=1e5;%2.5;
% % % % % %         sc=2.5e3;
% % %         zq = ones(size(xq))*1e10;
% % %         quiver3(xq,yq,zq,tot_E_field_x/sc,tot_E_field_y/sc,zeros(size(xq)),0,'b');hold on;
% % % % %         plot(pos_bef_0(1),pos_bef_0(2),'or');
% % % % %         plot(pos_aft(1),pos_aft(2),'ob');
% % % % %         axis equal;
% % % % %         xlim([-1 1]);
% % % % %         ylim([0 2]);
% % % % %         view([0 90]);
% % % % %         colorbar;
% % % % %         colormap(redblue);
% % % % %         set(gca,'fontsize',15);
% % %         xlabel('x [m]');        ylabel('y [m]');
% % %         titlename = append('Time step = ',num2str(ts));
% % %         title(titlename);
% % %         set(gca,'fontsize',13);
% % %         savename = append('E_field_amp_BOR_ts=',num2str(ts),'.png');
% % %         saveas(gca,savename);
% % %         pause(0.1);        
% % %     end

end
