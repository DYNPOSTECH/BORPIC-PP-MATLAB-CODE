function [Wh_1_t_unit_vec,Wh_2_n_unit_vec]=...
    Whitney_1_2_forms_unit_vec_2D(N_1,N_2,nod_crdn,edg_nod,fac_nod)

Wh_1_t_unit_vec=zeros(N_1,2);
for i=1:N_1
    edg_nod_a=nod_crdn(edg_nod(i,1),:);
    edg_nod_b=nod_crdn(edg_nod(i,2),:);        
    t_vec=edg_nod_b-edg_nod_a;
    Wh_1_t_unit_vec(i,:)=t_vec/norm(t_vec);
end

Wh_2_n_unit_vec=zeros(N_2,1);
for i=1:N_2
    fac_nod_a=nod_crdn(fac_nod(i,1),:);
    fac_nod_b=nod_crdn(fac_nod(i,2),:);
    fac_nod_c=nod_crdn(fac_nod(i,3),:);    
    vec_a=fac_nod_b-fac_nod_a;
    vec_b=fac_nod_c-fac_nod_a;
    n_vec=cross([vec_a,0],[vec_b,0]);
    n_vec=n_vec(3);
    Wh_2_n_unit_vec(i,:)=n_vec/norm(n_vec);
end

end