clear all; clc; close all;

x_line=[0.2,1]+10;
y_line=[0.2,-1]+10;
x_tri = [-1 2 1];
y_tri = [-2 0 2];
figure;
plot(x_line,y_line,'r');hold on;
plot(x_tri,y_tri,'-ob');hold on;
plot([x_tri(3),x_tri(1)],[y_tri(3),y_tri(1)],'-ob');hold on;

x_tri = [x_tri,x_tri(1)];
y_tri = [y_tri,y_tri(1)];
[xi,yi] = polyxpoly(x_line,y_line,x_tri,y_tri);