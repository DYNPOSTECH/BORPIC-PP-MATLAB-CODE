function B_field_val = B_field_Interpolation_2D(b_dof,fac_idx,fac_area,fac_nod,nod_crdn)

fac_nod_a=nod_crdn(fac_nod(fac_idx,1),:);
fac_nod_b=nod_crdn(fac_nod(fac_idx,2),:);
fac_nod_c=nod_crdn(fac_nod(fac_idx,3),:);    
vec_a=fac_nod_b-fac_nod_a;
vec_b=fac_nod_c-fac_nod_a;
n_vec=cross([vec_a,0],[vec_b,0]);
B_field_val=sign(n_vec(3))/fac_area(fac_idx)*b_dof(fac_idx);

end