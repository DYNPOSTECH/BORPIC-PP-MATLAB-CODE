function fac_idx = Find_Few_Faces_Close_to_Point(pos,fac_cent_crdn,N_fac)
    dist = sqrt( (pos(1)-fac_cent_crdn(:,1)).^2 + (pos(2)-fac_cent_crdn(:,2)).^2  );
    [~,ccc]=sort(dist);

    fac_idx=ccc(1:N_fac);
end