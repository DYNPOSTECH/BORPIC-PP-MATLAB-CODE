function n_vec_sign = W2_Normal_Vector_Sign(G_mat,N_2)
n_vec_sign = zeros(N_2,1);

for i=1:N_2    
    grad_lambda_1 = zeros(3,1);
    grad_lambda_2 = zeros(3,1);

    grad_lambda_1(1:2) = G_mat(1,1:2,i);
    grad_lambda_2(1:2) = G_mat(2,1:2,i);
    
    W2_dir_vec = cross(grad_lambda_1,grad_lambda_2);
    n_vec_sign(i) = sign(W2_dir_vec(3));
end