# BORPIC-PP-MATLAB-code-TE-phi-Line-Source-EM-Simulations-
Body-of-revolution FETD scheme for TE phi polarized fields (Line source EM simulations)
