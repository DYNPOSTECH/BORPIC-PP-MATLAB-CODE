function L_mat_sp_mat = L_mat_Gen(edg_fac_up_down,N_1,N_2,up_down_opt,x_y_opt,G_mat,fac_area,fac_edg)

[eps_0,mu_0,eta_0,c]=Constants_func();

L_mat_sp_i=zeros(20*N_1,1);
L_mat_sp_j=zeros(20*N_1,1);
L_mat_sp_v=zeros(20*N_1,1);
cnt_eps=0;

for i=1:N_2
    G_mat_temp=G_mat(:,:,i);
    
    vec_1=transpose(G_mat_temp(1,1:2));
    vec_2=transpose(G_mat_temp(2,1:2));
    vec_3=transpose(G_mat_temp(3,1:2));    
    
    loc_L_mat_matrix=zeros(3,3);
    
    loc_L_mat_matrix(1,1)=...
        2*transpose(vec_2(x_y_opt))*vec_2(x_y_opt)-...
        1*transpose(vec_2(x_y_opt))*vec_1(x_y_opt)-...
        1*transpose(vec_1(x_y_opt))*vec_2(x_y_opt)+...
        2*transpose(vec_1(x_y_opt))*vec_1(x_y_opt);
    
    loc_L_mat_matrix(1,2)=...
        2*transpose(vec_2(x_y_opt))*vec_3(x_y_opt)-...
        1*transpose(vec_2(x_y_opt))*vec_1(x_y_opt)-...
        1*transpose(vec_1(x_y_opt))*vec_3(x_y_opt)+...
        1*transpose(vec_1(x_y_opt))*vec_1(x_y_opt);
    
    loc_L_mat_matrix(1,3)=...
        1*transpose(vec_2(x_y_opt))*vec_3(x_y_opt)-...
        1*transpose(vec_2(x_y_opt))*vec_2(x_y_opt)-...
        2*transpose(vec_1(x_y_opt))*vec_3(x_y_opt)+...
        1*transpose(vec_1(x_y_opt))*vec_2(x_y_opt);
    
    loc_L_mat_matrix(2,1)=loc_L_mat_matrix(1,2);
    
    loc_L_mat_matrix(2,2)=...
        2*transpose(vec_3(x_y_opt))*vec_3(x_y_opt)-...
        1*transpose(vec_3(x_y_opt))*vec_1(x_y_opt)-...
        1*transpose(vec_1(x_y_opt))*vec_3(x_y_opt)+...
        2*transpose(vec_1(x_y_opt))*vec_1(x_y_opt);
    
    loc_L_mat_matrix(2,3)=...
        1*transpose(vec_3(x_y_opt))*vec_3(x_y_opt)-...
        1*transpose(vec_3(x_y_opt))*vec_2(x_y_opt)-...
        1*transpose(vec_1(x_y_opt))*vec_3(x_y_opt)+...
        2*transpose(vec_1(x_y_opt))*vec_2(x_y_opt);
    
    loc_L_mat_matrix(3,1)=loc_L_mat_matrix(1,3);
    loc_L_mat_matrix(3,2)=loc_L_mat_matrix(2,3);
    
    loc_L_mat_matrix(3,3)=...
        2*transpose(vec_3(x_y_opt))*vec_3(x_y_opt)-...
        1*transpose(vec_3(x_y_opt))*vec_2(x_y_opt)-...
        1*transpose(vec_2(x_y_opt))*vec_3(x_y_opt)+...
        2*transpose(vec_2(x_y_opt))*vec_2(x_y_opt);
    
    loc_L_mat_matrix=loc_L_mat_matrix*2*fac_area(i)/24;%*eps_0*eps_r(i);
    
    

    for ii=1:3  
        glb_i_idx=fac_edg(i,ii);
        if edg_fac_up_down(glb_i_idx,up_down_opt)==i
            for jj=1:3
                glb_j_idx=fac_edg(i,jj);
                
                cnt_eps=cnt_eps+1;
                L_mat_sp_i(cnt_eps)=glb_i_idx;
                L_mat_sp_j(cnt_eps)=glb_j_idx;
                L_mat_sp_v(cnt_eps)=loc_L_mat_matrix(ii,jj);                
            end
        end
    end
end
L_mat_sp_i(cnt_eps+1:end)=[];
L_mat_sp_j(cnt_eps+1:end)=[];
L_mat_sp_v(cnt_eps+1:end)=[];

L_mat_sp_mat=sparse(L_mat_sp_i,L_mat_sp_j,L_mat_sp_v,N_1,N_1);
    
end