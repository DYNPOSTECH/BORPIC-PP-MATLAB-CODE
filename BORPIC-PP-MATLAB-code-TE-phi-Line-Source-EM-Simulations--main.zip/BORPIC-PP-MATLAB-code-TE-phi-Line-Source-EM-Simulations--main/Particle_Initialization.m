function [pos_bef,vel_bef,q_sp,m_sp]=Particle_Initialization()

[eps_0,mu_0,eta_0,c]=Constants_func();
q_e=-1.6e-19;
m_e=9.1e-31;

sp_fac=1e6;
pos_bef=[-0.2500012355;.85005012312354];
vel_bef=[0.02500305092318273982173;0.025012501123453215435]*c;
q_sp = q_e*sp_fac;
m_sp = m_e*sp_fac;

end