function W_mat_sp_mat = W_mat_Gen(cond_set,eps_r,edg_fac_up_down,N_1,N_2,up_down_opt,x_y_opt,G_mat,fac_area,fac_edg,del_t)

[eps_0,mu_0,eta_0,c]=Constants_func();

if x_y_opt==1
    opos_x_y_opt=2;
elseif x_y_opt==2
    opos_x_y_opt=1;
end
tau=2/del_t;

W_mat_sp_i=zeros(N_1,1);
W_mat_sp_j=zeros(N_1,1);
W_mat_sp_v=zeros(N_1,1);
cnt_eps=0;
for i=1:N_1
    fac_idx=edg_fac_up_down(i,up_down_opt);
    if fac_idx==0        
    else    
        r_0 = cond_set(fac_idx,x_y_opt);
        r_1 = eps_0;

        q_0 = cond_set(fac_idx,opos_x_y_opt)*eps_r(fac_idx);
        q_1 = eps_0*eps_r(fac_idx);
        
        w = (q_0 + tau*q_1)/(r_0 + tau*r_1);
    
        cnt_eps=cnt_eps+1;
        W_mat_sp_i(cnt_eps)=i;
        W_mat_sp_j(cnt_eps)=i;
        W_mat_sp_v(cnt_eps)=w;
    end
end
W_mat_sp_i(cnt_eps+1:end)=[];
W_mat_sp_j(cnt_eps+1:end)=[];
W_mat_sp_v(cnt_eps+1:end)=[];

W_mat_sp_mat=sparse(W_mat_sp_i,W_mat_sp_j,W_mat_sp_v,N_1,N_1);
    
end
