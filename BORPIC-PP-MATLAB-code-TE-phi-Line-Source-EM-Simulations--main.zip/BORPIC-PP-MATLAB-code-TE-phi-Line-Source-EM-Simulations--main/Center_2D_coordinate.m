function [fac_cent_crdn,edg_cent_crdn]=Center_2D_coordinate(...
    N_2,N_1,nod_crdn,fac_nod,edg_nod)

    fac_cent_crdn=zeros(N_2,2);    
    for i=1:N_2
        for j=1:3
            fac_cent_crdn(i,:)=fac_cent_crdn(i,:)+nod_crdn(fac_nod(i,j),:)/3;
        end
    end
    
    edg_cent_crdn=zeros(N_1,2);    
    for i=1:N_1
        for j=1:2
            edg_cent_crdn(i,:)=edg_cent_crdn(i,:)+nod_crdn(edg_nod(i,j),:)/2;
        end
    end
    
end