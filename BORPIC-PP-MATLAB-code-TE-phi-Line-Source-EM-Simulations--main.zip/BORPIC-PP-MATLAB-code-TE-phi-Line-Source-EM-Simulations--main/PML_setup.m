function [cond_set,ele_pml_idx]=PML_setup(N_3,PML_st,cond_0,h,PML_L,pml_order,ele_cent_crdn)

ele_pml_idx=zeros(N_3,3);
cond_set=zeros(N_3,3);
for i=1:N_3    
    for j=1:3
        if abs(ele_cent_crdn(i,j)) >= PML_st+PML_st*1e-15
            ele_pml_idx(i,j)=1;
            cond_set(i,j)=cond_0*...
                abs(...
                ( floor((PML_st-abs( ele_cent_crdn(i,j)))/h)+1 )*h/PML_L ...
                )^pml_order;
        end
    end
end

end