function [u_set,v_set,w_val] = QR_UVW_mu_Converter(q_set,r_set,del_t,N_2)
tau = 2/del_t;

Lambda = (r_set(:,0+1) + tau*r_set(:,1+1) + tau^2*r_set(:,2+1));
Lambda_inv = 1./Lambda;

w_val = Lambda_inv.*(q_set(:,0+1) + tau*q_set(:,1+1) + tau^2*q_set(:,2+1));

u_set = zeros(N_2,2+1);
v_set = zeros(N_2,2+1);

u_set(:,0+1) = Lambda_inv.*( tau*r_set(:,1+1) + tau^2*r_set(:,2+1) );
u_set(:,1+1) = Lambda_inv.*( r_set(:,1+1) + 2*tau*r_set(:,2+1) );
u_set(:,2+1) = Lambda_inv.*( r_set(:,2+1) );

v_set(:,0+1) = Lambda_inv.*( tau*q_set(:,1+1) + tau^2*q_set(:,2+1) );
v_set(:,1+1) = Lambda_inv.*( q_set(:,1+1) + 2*tau*q_set(:,2+1) );
v_set(:,2+1) = Lambda_inv.*( q_set(:,2+1) );

end