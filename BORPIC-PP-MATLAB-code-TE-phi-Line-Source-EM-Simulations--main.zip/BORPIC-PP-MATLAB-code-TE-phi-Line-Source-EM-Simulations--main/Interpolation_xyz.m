function [xi,yi,zi]=Interpolation_xyz()
end