function vec_field=Wh_1_interp_2D(r,fac_idx,G_mat,dof,fac_edg)

G_mat_temp=G_mat(:,:,fac_idx);
lambda=G_mat_temp*[r(1);r(2);1];
vec_field=zeros(2,1);

Wh_1_1=lambda(1)*G_mat_temp(2,1:2)-lambda(2)*G_mat_temp(1,1:2);
Wh_1_2=lambda(1)*G_mat_temp(3,1:2)-lambda(3)*G_mat_temp(1,1:2);
Wh_1_3=lambda(2)*G_mat_temp(3,1:2)-lambda(3)*G_mat_temp(2,1:2);

Wh_1_1=Wh_1_1';Wh_1_2=Wh_1_2';Wh_1_3=Wh_1_3';

vec_field=vec_field+...
    dof(fac_edg(fac_idx,1))*Wh_1_1+...
    dof(fac_edg(fac_idx,2))*Wh_1_2+...
    dof(fac_edg(fac_idx,3))*Wh_1_3;    
end