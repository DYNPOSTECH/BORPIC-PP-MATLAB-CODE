function g_xy_eps = g_xy_eps_Gen_v3(u_eps_set,v_eps_set,d_dof_sp_set,e_dof_sp_set)

g_xy_eps = sum(d_dof_sp_set.*u_eps_set,2) - sum(e_dof_sp_set.*v_eps_set,2);

end