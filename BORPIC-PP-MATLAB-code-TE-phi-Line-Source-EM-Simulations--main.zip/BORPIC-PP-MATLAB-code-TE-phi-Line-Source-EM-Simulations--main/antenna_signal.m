clear all; clc; close all;

c=3e8;
N_t= 10000;
del_t=0.001/c;
ant_pos = [0.0001,0.8501];
time=[0:del_t:(N_t-1)*del_t];
f_source=zeros(N_t,1);
f_0 =1e9;
w_0 = 2*pi*f_0;
per=2;
for ts = 1:N_t
    if time(ts) < per*2*pi/w_0
        f_source(ts) = sin(w_0*time(ts));
    end
end
T_0 = 2*pi/w_0;
figure;
plot(time/T_0,f_source,'b','linewidth',1);
set(gca,'fontsize',12);
xlabel('normalized time, t/T');
ylabel('f(t/T)');
xlim([0 5]);