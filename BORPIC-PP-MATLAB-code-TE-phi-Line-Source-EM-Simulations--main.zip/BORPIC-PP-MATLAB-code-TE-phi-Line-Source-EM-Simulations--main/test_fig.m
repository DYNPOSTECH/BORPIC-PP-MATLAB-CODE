clear all; clc; close all;

x=[1,2];
y=[3,4];
u=[1,1];
v=[0,2];

figure;
quiver(x,y,u,v);