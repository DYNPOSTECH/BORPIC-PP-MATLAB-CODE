clear all; clc; close all;

%% Constants
[eps_0,mu_0,eta_0,c]=Constants_func();

inv_opt=1;

%% SPAI order
order_p = 3;

% 1 PML outer boundary / 0 PML interface
top_reflecting_opt = 0;

% time discretization
del_t=0.001/c;
N_t=50001;

% geometry
z_min = -.5;
z_max =  .5;
r_min = 0;
r_max = 1.;
pml_l = 0.025;
pml_N = 5;
pml_length_tot = pml_l*pml_N;

% pml parameter
PML_ll_x_st=z_min;
PML_rr_x_st=z_max;
PML_dd_y_st=r_min;
PML_uu_y_st=r_max;

PML_N=pml_N;
PML_h=pml_l;
PML_L=pml_length_tot;

L_x_tot = z_max - z_min;
L_y_tot = r_max + pml_length_tot;

pml_order=2;
cond_0=0.5;

% gaussian quadrature parameter
GC_order_p=2;

%% Mesh information getter
disp('- Reading mesh files...') 
tic
load nod_crdn.txt;
load fac_nod.txt;
nod_crdn=nod_crdn(:,2:3);
fac_org_idx=fac_nod(:,1);
fac_nod=fac_nod(:,2:4);
fac_nod=sort(fac_nod,2);
N_0=size(nod_crdn,1);
N_2=size(fac_nod,1);
toc

disp('- Mesh information getter...') 
tic
[...
    N_0,N_1,N_2,DT,...    
    fac_edg,fac_nod,...
    edg_nod,...
    edg_length,...
    nod_crdn]=FEM_2D_Mesh_Getter_gmsh(nod_crdn,fac_nod,N_0,N_2);
toc

disp('- X_mat, G_mat, gradient of barycentric coordinate s getter...')
tic
[X_mat,G_mat,fac_area]=FEM_2D_X_G_Mat_Gen(N_2,fac_nod,nod_crdn);
toc

figure;
triplot(DT);

% center coordinates of element, face, and edges
[fac_cent_crdn,edg_cent_crdn]=Center_2D_coordinate(...
    N_2,N_1,nod_crdn,fac_nod,edg_nod);
disp(append('- DoFs (# of edges) = ',num2str(N_1)));

% mesh plot
edg_x=[nod_crdn(edg_nod(:,1),1),nod_crdn(edg_nod(:,2),1)]';
edg_y=[nod_crdn(edg_nod(:,1),2),nod_crdn(edg_nod(:,2),2)]';

% PBC edges finder
[rr,~]=find(edg_cent_crdn(:,1)==z_min);% & edg_cent_crdn(:,2)<= r_max );
pbc_lef_edg_idx=rr;
[rr,~]=find(edg_cent_crdn(:,1)==z_max);% & edg_cent_crdn(:,2)<= r_max );
pbc_rig_edg_idx=rr;
pbc_edg_idx=[pbc_lef_edg_idx,pbc_rig_edg_idx];
N_pbc_edg = length(pbc_rig_edg_idx);

% boundary edges
bc_edg=zeros(N_1,1);

if top_reflecting_opt == 0
    [rr,~]=find(edg_cent_crdn(:,2)==r_max);
elseif top_reflecting_opt == 1
    [rr,~]=find(edg_cent_crdn(:,2)==L_y_tot);
end
top_edg_idx=rr;
[rr,~]=find(edg_cent_crdn(:,2)==r_min);
bot_edg_idx=rr;
bc_edg(bot_edg_idx)=1;
bc_edg(top_edg_idx)=2;
bc_edg(pbc_lef_edg_idx)=3;
bc_edg(pbc_rig_edg_idx)=4;

fac_edg_org = fac_edg;
for ii=1:N_pbc_edg
    rig_idx = pbc_rig_edg_idx(ii);
    lef_idx = pbc_lef_edg_idx(ii);
    for i=1:N_2
        [det,loc]=ismember(rig_idx,fac_edg_org(i,:));
        if det==1
            fac_edg(i,loc) = lef_idx;
        end
    end
end

%% Perfectly Matched Layers
[cond_set,~]=...
    PML_setup_BOR(N_2,...
    PML_ll_x_st,PML_rr_x_st,PML_dd_y_st,PML_uu_y_st,...
    cond_0,PML_h,PML_L,pml_order,fac_cent_crdn);

fac_pml_idx = sum(cond_set,2);
rr=find(fac_pml_idx~=0);
fac_pml_idx=rr;
N_2_pml = length(fac_pml_idx);

fac_non_pml_idx = 1:N_2;
fac_non_pml_idx(fac_pml_idx)=[];
N_2_non_pml = length(fac_non_pml_idx);

nod_pml_idx = fac_nod(fac_pml_idx,:);
nod_pml_idx = nod_pml_idx(:);
nod_pml_idx = unique(nod_pml_idx);

nod_non_pml_idx = 1:N_0;
nod_non_pml_idx = nod_non_pml_idx';
nod_non_pml_idx(nod_pml_idx)=[];

nod_idx_pml_non_pml=[nod_non_pml_idx;nod_pml_idx];


%% --------------------------------------------------------------------- %%
%% FEM system matrix
disp('Incidence matrix');
tic
inc_sp_mat_org=Incidence_Mat_Gen_2D(N_2,N_1,fac_edg_org);
inc_sp_mat=Incidence_Mat_Gen_2D(N_2,N_1,fac_edg);
dual_inc_sp_mat_org=transpose(inc_sp_mat_org);
dual_inc_sp_mat=transpose(inc_sp_mat);

grad_inc_sp_mat=Grad_Incidence_Mat_Gen_2D(N_1,N_0,edg_nod);
div_inc_sp_mat=transpose(grad_inc_sp_mat);
toc

%% PML related L and W matrix generation
tic
edg_fac_up_dn = zeros(N_1,2);
disp('- finding edge-face up dn ...');
pbc_rig_idx_check = zeros(N_1,1);
for i=1:N_1    
    nz_col = find( dual_inc_sp_mat(i,:)~=0 );
    if length(nz_col)==2
        edg_fac_up_dn(i,:)=nz_col;
    elseif length(nz_col)==1
        edg_fac_up_dn(i,1)=nz_col;
    else        
        pbc_rig_idx_check(i) = 1;
    end    
end

tic
disp('-finding index of edges that touch faces of PML...');
edg_pml_idx = zeros(N_2*3,1);
cnt_st=1;
for i=1:N_2_pml
    cnt_end=cnt_st+2;
    edg_pml_idx(cnt_st:cnt_end)=fac_edg(fac_pml_idx(i),:);
%     edg_pml_idx(cnt_st:cnt_end)=fac_edg(i,:);
    cnt_st=cnt_end+1;
end
edg_pml_idx=unique(edg_pml_idx);
edg_pml_idx(edg_pml_idx==0)=[];
N_1_pml = length(edg_pml_idx);
edg_pml_fac_up_dn = edg_fac_up_dn(edg_pml_idx,:);
toc

% L matrix generation
x_y_opt=1; up_dn_opt=1; 
L_mat_sp_x_up    = L_mat_Gen(edg_fac_up_dn,N_1,N_2,up_dn_opt,x_y_opt,G_mat,fac_area,fac_edg);
x_y_opt=1; up_dn_opt=2; 
L_mat_sp_x_dn  = L_mat_Gen(edg_fac_up_dn,N_1,N_2,up_dn_opt,x_y_opt,G_mat,fac_area,fac_edg);
x_y_opt=2; up_dn_opt=1; 
L_mat_sp_y_up    = L_mat_Gen(edg_fac_up_dn,N_1,N_2,up_dn_opt,x_y_opt,G_mat,fac_area,fac_edg);
x_y_opt=2; up_dn_opt=2; 
L_mat_sp_y_dn  = L_mat_Gen(edg_fac_up_dn,N_1,N_2,up_dn_opt,x_y_opt,G_mat,fac_area,fac_edg);

L_mat_sp = L_mat_sp_x_up + L_mat_sp_x_dn + L_mat_sp_y_up + L_mat_sp_y_dn;


%% W matrix generation
% relative permittivity and permeability encoding \rho
eps_r = fac_cent_crdn(:,2)*eps_0;
mu_r = mu_0./fac_cent_crdn(:,2);

x_y_opt = 1;up_dn_opt = 1;
W_mat_sp_x_up    = W_mat_Gen(cond_set,eps_r,edg_fac_up_dn,N_1,N_2,up_dn_opt,x_y_opt,G_mat,fac_area,fac_edg,del_t);
x_y_opt = 1;up_dn_opt = 2;
W_mat_sp_x_dn  = W_mat_Gen(cond_set,eps_r,edg_fac_up_dn,N_1,N_2,up_dn_opt,x_y_opt,G_mat,fac_area,fac_edg,del_t);
x_y_opt = 2;up_dn_opt = 1;
W_mat_sp_y_up    = W_mat_Gen(cond_set,eps_r,edg_fac_up_dn,N_1,N_2,up_dn_opt,x_y_opt,G_mat,fac_area,fac_edg,del_t);
x_y_opt = 2;up_dn_opt = 2;
W_mat_sp_y_dn  = W_mat_Gen(cond_set,eps_r,edg_fac_up_dn,N_1,N_2,up_dn_opt,x_y_opt,G_mat,fac_area,fac_edg,del_t);

WL_x_up      = W_mat_sp_x_up*L_mat_sp_x_up;
WL_x_dn    = W_mat_sp_x_dn*L_mat_sp_x_dn;
WL_y_up      = W_mat_sp_y_up*L_mat_sp_y_up;
WL_y_dn    = W_mat_sp_y_dn*L_mat_sp_y_dn;

A_eps_mat_sp =  WL_x_up + WL_x_dn + WL_y_up + WL_y_dn;
A_eps_mat_sp(pbc_rig_edg_idx,pbc_rig_edg_idx) = eye(N_pbc_edg);

if inv_opt==1
    % SPAI
    [r_SP,c_SP]=find(A_eps_mat_sp~=0);
    N_nz=length(r_SP);
    SP_A_eps_mat_sp = sparse(r_SP,c_SP,ones(N_nz,1));
    
    for i=1:order_p-1
        SP_A_eps_mat_sp = SP_A_eps_mat_sp*SP_A_eps_mat_sp;
    end
    [r_SP_final,c_SP_final]=find(SP_A_eps_mat_sp~=0);
    N_nz_final=length(r_SP_final);
    
    I_mat_sp = speye(N_1);
    
    disp('SPAI...')
    tic
    A_eps_inv_SPAI_mat_sp=SPAI(A_eps_mat_sp, SP_A_eps_mat_sp, I_mat_sp, N_1);
    toc
    A_eps_inv_SPAI_mat_sp(pbc_rig_edg_idx,pbc_rig_edg_idx) = 0;
elseif inv_opt==2
    I_mat_sp = speye(N_1);
    disp('LUD...')
    tic
    A_eps_inv_SPAI_mat_sp=A_eps_mat_sp\I_mat_sp;
    toc
    A_eps_inv_SPAI_mat_sp(pbc_rig_edg_idx,pbc_rig_edg_idx) = 0;
end

%% Mu system matrix
L_z_mat_sp_mat = L_z_mat_Gen(N_2,fac_area);
W_z_mat_sp_mat = W_z_mat_Gen(cond_set,N_2,del_t,mu_r);
A_mu_inv_mat_sp = W_z_mat_sp_mat*L_z_mat_sp_mat;

%% --------------------------------------------------------------------- %%

%% dynamical variables for time update
b_bef_0_sp=sparse(N_2,1); b_bef_1_sp=sparse(N_2,1); b_bef_2_sp=sparse(N_2,1);
b_aft_0_sp=sparse(N_2,1); b_aft_1_sp=sparse(N_2,1); b_aft_2_sp=sparse(N_2,1);
h_bef_0_sp=sparse(N_2,1); h_bef_1_sp=sparse(N_2,1); h_bef_2_sp=sparse(N_2,1);

h_aft_0_sp=sparse(N_2,1); h_aft_1_sp=sparse(N_2,1); h_aft_2_sp=sparse(N_2,1);
d_bef_0_sp=sparse(N_1,1); d_aft_0_sp=sparse(N_1,1);

d_bef_0_x_up_sp = sparse(N_1_pml,1); d_bef_0_x_dn_sp = sparse(N_1_pml,1);
d_bef_0_y_up_sp = sparse(N_1_pml,1); d_bef_0_y_dn_sp = sparse(N_1_pml,1);
d_bef_1_x_up_sp = sparse(N_1_pml,1); d_bef_1_x_dn_sp = sparse(N_1_pml,1);
d_bef_1_y_up_sp = sparse(N_1_pml,1); d_bef_1_y_dn_sp = sparse(N_1_pml,1);

e_bef_0_sp=sparse(N_1,1); e_aft_0_sp=sparse(N_1,1);

e_bef_0_x_up_sp = sparse(N_1_pml,1); e_bef_0_x_dn_sp = sparse(N_1_pml,1);
e_bef_0_y_up_sp = sparse(N_1_pml,1); e_bef_0_y_dn_sp = sparse(N_1_pml,1);
e_bef_1_x_up_sp = sparse(N_1_pml,1); e_bef_1_x_dn_sp = sparse(N_1_pml,1);
e_bef_1_y_up_sp = sparse(N_1_pml,1); e_bef_1_y_dn_sp = sparse(N_1_pml,1);

% u v parameters
x_y_opt = 1;up_dn_opt = 1;
[u_eps_x_up_set,v_eps_x_up_set] = ...
    UV_eps_set(N_1_pml,edg_pml_fac_up_dn,up_dn_opt,x_y_opt,del_t,cond_set,eps_r);
x_y_opt = 1;up_dn_opt = 2;
[u_eps_x_dn_set,v_eps_x_dn_set] = ...
    UV_eps_set(N_1_pml,edg_pml_fac_up_dn,up_dn_opt,x_y_opt,del_t,cond_set,eps_r);
x_y_opt = 2;up_dn_opt = 1;
[u_eps_y_up_set,v_eps_y_up_set] = ...
    UV_eps_set(N_1_pml,edg_pml_fac_up_dn,up_dn_opt,x_y_opt,del_t,cond_set,eps_r);
x_y_opt = 2;up_dn_opt = 2;
[u_eps_y_dn_set,v_eps_y_dn_set] = ...
    UV_eps_set(N_1_pml,edg_pml_fac_up_dn,up_dn_opt,x_y_opt,del_t,cond_set,eps_r);

% source test
ant_pos = [0.0001,0.8501];
time=[0:del_t:(N_t-1)*del_t];
f_source=zeros(N_t,1);
f_0 =1e9;
w_0 = 2*pi*f_0;
per=2;
for ts = 1:N_t
    if time(ts) < per*2*pi/w_0
        f_source(ts) = sin(w_0*time(ts));
    end
end

dist=zeros(N_1,1);
for i=1:N_1
    dist(i,1) = sqrt( (edg_cent_crdn(i,1) - ant_pos(1))^2 + (edg_cent_crdn(i,2) - ant_pos(2))^2 );
end
rrr=find(dist==min(dist));
ant_idx=rrr;

ant_pos_st = [-0.50;0.750000012354];
ant_pos_en = [+0.50;0.750000120391];
% --------------------------------------------------------------------- %
% --------------------------------------------------------------------- %
% ---------------------------Time update------------------------------- %
% --------------------------------------------------------------------- %
% --------------------------------------------------------------------- %

for ts = 1:N_t
    if mod(ts,10)==1
        disp(append('time index = ',num2str(ts)))
    end    
    
    if ts>1
        % dynamical variable update
        b_bef_0_sp = b_aft_0_sp; b_bef_1_sp = b_aft_1_sp; b_bef_2_sp = b_aft_2_sp;
        h_bef_0_sp = h_aft_0_sp; h_bef_1_sp = h_aft_1_sp; h_bef_2_sp = h_aft_2_sp;
        d_bef_0_sp = d_aft_0_sp;       

        d_bef_0_x_up_sp = d_aft_0_x_up_sp; d_bef_0_x_dn_sp = d_aft_0_x_dn_sp;
        d_bef_0_y_up_sp = d_aft_0_y_up_sp; d_bef_0_y_dn_sp = d_aft_0_y_dn_sp;

        d_bef_1_x_up_sp = d_aft_1_x_up_sp; d_bef_1_x_dn_sp = d_aft_1_x_dn_sp;
        d_bef_1_y_up_sp = d_aft_1_y_up_sp; d_bef_1_y_dn_sp = d_aft_1_y_dn_sp;

        e_bef_0_sp = e_aft_0_sp;

        e_bef_0_x_up_sp = e_aft_0_x_up_sp; e_bef_0_x_dn_sp = e_aft_0_x_dn_sp;
        e_bef_0_y_up_sp = e_aft_0_y_up_sp; e_bef_0_y_dn_sp = e_aft_0_y_dn_sp;
        
        e_bef_1_x_up_sp = e_aft_1_x_up_sp; e_bef_1_x_dn_sp = e_aft_1_x_dn_sp;
        e_bef_1_y_up_sp = e_aft_1_y_up_sp; e_bef_1_y_dn_sp = e_aft_1_y_dn_sp;
    end    

    
    % Discrete Faraday's law for b_aft
    b_aft_0_sp = b_bef_0_sp - del_t*inc_sp_mat*e_bef_0_sp;    

    b_aft_1_sp = -b_bef_1_sp + 2/del_t*( b_aft_0_sp - b_bef_0_sp );
    b_aft_2_sp = -b_bef_2_sp + 2/del_t*( b_aft_1_sp - b_bef_1_sp );    
       
    % PML mu part
    b_dof_sp_set=[b_bef_0_sp(fac_pml_idx),b_bef_1_sp(fac_pml_idx),b_bef_2_sp(fac_pml_idx)];
    b_dof_sp_set = L_z_mat_sp_mat(fac_pml_idx,fac_pml_idx)*b_dof_sp_set;
    h_dof_sp_set=[h_bef_0_sp(fac_pml_idx),h_bef_1_sp(fac_pml_idx),h_bef_2_sp(fac_pml_idx)];   
    
    g_mu_bef = g_z_bef_Gen_v2(N_2_pml,del_t,b_dof_sp_set,h_dof_sp_set,cond_set,mu_r,fac_pml_idx);
    g_mu_bef_sp = sparse(fac_pml_idx,ones(N_2_pml,1),g_mu_bef,N_2,1);
    
    % Converting b_aft to h_aft
    h_aft_0_sp = A_mu_inv_mat_sp*b_aft_0_sp + g_mu_bef_sp;
    
    h_aft_1_sp = -h_bef_1_sp + 2/del_t*( h_aft_0_sp - h_bef_0_sp );
    h_aft_2_sp = -h_bef_2_sp + 2/del_t*( h_aft_1_sp - h_bef_1_sp );
      
    if ts==1
        j_bef=zeros(N_1,1);

        pos_bef = ant_pos_st;
        pos_aft = ant_pos_en;

        % Scatter
        fac_idx_pos_bef = Find_Fac(pos_bef,fac_cent_crdn,nod_crdn,fac_nod);
        fac_idx_pos_aft = Find_Fac(pos_aft,fac_cent_crdn,nod_crdn,fac_nod);
        
        % CASE B 
        fac_idx_pos_bef_temp = fac_idx_pos_bef;            
        pos_bef_temp = pos_bef;
        cnt_wh=0;
        cross_edg_idx_bef=-1;
        while fac_idx_pos_bef_temp ~= fac_idx_pos_aft
            cnt_wh=cnt_wh+1;               

            [cross_edg_idx,x_crs,y_crs] = Cross_Edg_Idx_Finder_v4(...
                    pos_bef_temp,pos_aft,fac_idx_pos_bef_temp,fac_edg,edg_nod,nod_crdn,cross_edg_idx_bef);
            
            cross_edg_idx_bef = cross_edg_idx;
            rr_idx = find(fac_idx_pos_bef_temp == edg_fac_up_dn(cross_edg_idx,:));
            fac_idx_temp = edg_fac_up_dn(cross_edg_idx,rr_idx);

            pos_aft_temp = [x_crs;y_crs];
            G_mat_temp = G_mat(:,:,fac_idx_temp);
            lambda_loc_s=G_mat_temp*[pos_bef_temp;1];
            lambda_loc_f=G_mat_temp*[pos_aft_temp;1];

            j_loc=Calc_Line_Current(lambda_loc_s,lambda_loc_f);
            for j=1:3
                j_bef(fac_edg(fac_idx_temp,j),1)=...
                    j_bef(fac_edg(fac_idx_temp,j),1)+j_loc(j);
            end

            % next 
            rr_idx = find(fac_idx_pos_bef_temp ~= edg_fac_up_dn(cross_edg_idx,:));
            fac_idx_pos_bef_temp = edg_fac_up_dn(cross_edg_idx,rr_idx);
            pos_bef_temp = pos_aft_temp;                

            if cnt_wh>500
                error2
            end  
        end
            
        fac_idx_temp = fac_idx_pos_bef_temp;
        pos_aft_temp = pos_aft;
        G_mat_temp = G_mat(:,:,fac_idx_temp);
        lambda_loc_s=G_mat_temp*[pos_bef_temp;1];
        lambda_loc_f=G_mat_temp*[pos_aft_temp;1];

        j_loc=Calc_Line_Current(lambda_loc_s,lambda_loc_f);
        for j=1:3
            j_bef(fac_edg(fac_idx_pos_bef,j),1)=j_bef(fac_edg(fac_idx_pos_bef,j),1)+j_loc(j);
        end    

        if fac_idx_temp ~= fac_idx_pos_aft
            error
        end                          
%         j_bef_sp_temp=sparse(j_bef);
           
    end
    j_bef_sp=j_bef*f_source(ts);
    j_bef_sp=sparse(j_bef_sp);

    % Discrete Ampere's law for d_aft
    d_aft_0_sp = d_bef_0_sp + del_t*dual_inc_sp_mat*h_aft_0_sp - del_t*j_bef_sp;
    
    % PML related eps part
    d_dof_sp_set = [d_bef_0_x_up_sp,d_bef_1_x_up_sp];
    e_dof_sp_set = [e_bef_0_x_up_sp,e_bef_1_x_up_sp];    
    g_eps_x_up = g_xy_eps_Gen_v3(u_eps_x_up_set,v_eps_x_up_set,d_dof_sp_set,e_dof_sp_set);

    d_dof_sp_set = [d_bef_0_x_dn_sp,d_bef_1_x_dn_sp];
    e_dof_sp_set = [e_bef_0_x_dn_sp,e_bef_1_x_dn_sp];
    g_eps_x_dn = g_xy_eps_Gen_v3(u_eps_x_dn_set,v_eps_x_dn_set,d_dof_sp_set,e_dof_sp_set);

    d_dof_sp_set = [d_bef_0_y_up_sp,d_bef_1_y_up_sp];
    e_dof_sp_set = [e_bef_0_y_up_sp,e_bef_1_y_up_sp];    
    g_eps_y_up = g_xy_eps_Gen_v3(u_eps_y_up_set,v_eps_y_up_set,d_dof_sp_set,e_dof_sp_set);

    d_dof_sp_set = [d_bef_0_y_dn_sp,d_bef_1_y_dn_sp];
    e_dof_sp_set = [e_bef_0_y_dn_sp,e_bef_1_y_dn_sp];    
    g_eps_y_dn = g_xy_eps_Gen_v3(u_eps_y_dn_set,v_eps_y_dn_set,d_dof_sp_set,e_dof_sp_set);
    
    g_eps_bef = g_eps_x_up + g_eps_x_dn + g_eps_y_up + g_eps_y_dn;
    g_eps_bef_sp = sparse(edg_pml_idx,ones(N_1_pml,1),g_eps_bef,N_1,1);
    
    % Converting d_aft to e_aft
    e_aft_0_sp = A_eps_inv_SPAI_mat_sp*(d_aft_0_sp - g_eps_bef_sp);
    
    % update variables
    e_aft_0_x_up_sp = L_mat_sp_x_up(edg_pml_idx,edg_pml_idx)*e_aft_0_sp(edg_pml_idx);
    e_aft_0_x_dn_sp = L_mat_sp_x_dn(edg_pml_idx,edg_pml_idx)*e_aft_0_sp(edg_pml_idx);
    e_aft_0_y_up_sp = L_mat_sp_y_up(edg_pml_idx,edg_pml_idx)*e_aft_0_sp(edg_pml_idx);
    e_aft_0_y_dn_sp = L_mat_sp_y_dn(edg_pml_idx,edg_pml_idx)*e_aft_0_sp(edg_pml_idx);
    
    d_aft_0_x_up_sp = W_mat_sp_x_up(edg_pml_idx,edg_pml_idx)*e_aft_0_x_up_sp + g_eps_x_up;
    d_aft_0_x_dn_sp = W_mat_sp_x_dn(edg_pml_idx,edg_pml_idx)*e_aft_0_x_dn_sp + g_eps_x_dn;
    d_aft_0_y_up_sp = W_mat_sp_y_up(edg_pml_idx,edg_pml_idx)*e_aft_0_y_up_sp + g_eps_y_up;
    d_aft_0_y_dn_sp = W_mat_sp_y_dn(edg_pml_idx,edg_pml_idx)*e_aft_0_y_dn_sp + g_eps_y_dn;

    e_aft_1_x_up_sp = -e_bef_1_x_up_sp + 2/del_t*( e_aft_0_x_up_sp - e_bef_0_x_up_sp );
    e_aft_1_x_dn_sp = -e_bef_1_x_dn_sp + 2/del_t*( e_aft_0_x_dn_sp - e_bef_0_x_dn_sp );
    e_aft_1_y_up_sp = -e_bef_1_y_up_sp + 2/del_t*( e_aft_0_y_up_sp - e_bef_0_y_up_sp );
    e_aft_1_y_dn_sp = -e_bef_1_y_dn_sp + 2/del_t*( e_aft_0_y_dn_sp - e_bef_0_y_dn_sp );
    
    d_aft_1_x_up_sp = -d_bef_1_x_up_sp + 2/del_t*( d_aft_0_x_up_sp - d_bef_0_x_up_sp );
    d_aft_1_x_dn_sp = -d_bef_1_x_dn_sp + 2/del_t*( d_aft_0_x_dn_sp - d_bef_0_x_dn_sp );
    d_aft_1_y_up_sp = -d_bef_1_y_up_sp + 2/del_t*( d_aft_0_y_up_sp - d_bef_0_y_up_sp );
    d_aft_1_y_dn_sp = -d_bef_1_y_dn_sp + 2/del_t*( d_aft_0_y_dn_sp - d_bef_0_y_dn_sp );
    T_ed_upd = toc;

% % %     if mod(ts,500)==1 
% % %             close all;   
% % % 
% % %             E_x=zeros(N_2,1);
% % %             E_y=zeros(N_2,1);
% % %             for iii=1:N_2
% % %                 ii=iii;
% % %                 E_vec_temp=Wh_1_interp_2D(fac_cent_crdn(ii,:),iii,G_mat,e_aft_0_sp,fac_edg);
% % %                 E_x(iii)=E_vec_temp(1);
% % %                 E_y(iii)=E_vec_temp(2);
% % %             end
% % % 
% % %             figure(100);
% % %             sc=2.5e0;
% % %             quiver(fac_cent_crdn(:,1),fac_cent_crdn(:,2),E_x/sc,E_y/sc,0,'b');hold on;
% % %             plot(pos_bef_0(1),pos_bef_0(2),'or');
% % %             plot(pos_aft(1),pos_aft(2),'ob');
% % %             plot3([z_min z_max],[r_max r_max],[100 100],'--r','linewidth',1);
% % %             axis equal;
% % % 
% % % % %             E_x=zeros(N_2_non_pml,1);
% % % % %             E_y=zeros(N_2_non_pml,1);
% % % % %             for iii=1:N_2_non_pml
% % % % %                 ii=fac_non_pml_idx(iii);
% % % % %                 E_vec_temp=Wh_1_interp_2D(fac_cent_crdn(ii,:),iii,G_mat,e_aft_0_sp,fac_edg);
% % % % %                 E_x(iii)=E_vec_temp(1);
% % % % %                 E_y(iii)=E_vec_temp(2);
% % % % %             end
% % % % % 
% % % % %             figure(100);
% % % % %             sc=2.5e0;
% % % % %             quiver(fac_cent_crdn(fac_non_pml_idx,1),fac_cent_crdn(fac_non_pml_idx,2),E_x/sc,E_y/sc,0,'b');hold on;
% % % % %             plot(pos_bef_0(1),pos_bef_0(2),'or');
% % % % %             plot(pos_aft(1),pos_aft(2),'ob');
% % % % %             plot3([z_min z_max],[r_max r_max],[100 100],'--r','linewidth',1);
% % % % %             axis equal;
% % % 
% % %             pause(0.1);
% % %     end

% % % if mod(ts,100)==1
% % %     close all;
% % %     e_interp_vec=e_aft_0_sp;              
% % %      
% % %     E_x=zeros(N_2,1);
% % %     E_y=zeros(N_2,1);
% % %     for iii=1:N_2
% % %         ii=iii;
% % %         E_vec_temp=Wh_1_interp_2D(fac_cent_crdn(ii,:),iii,G_mat,e_aft_0_sp,fac_edg);
% % %         E_x(iii)=E_vec_temp(1);
% % %         E_y(iii)=E_vec_temp(2);
% % %     end
% % %     sc=5e3;        
% % %     quiver(fac_cent_crdn(:,1),fac_cent_crdn(:,2),E_x/sc,E_y/sc,0,'b');hold on;
% % %     plot([pos_bef(1),pos_aft(1)],[pos_bef(2),pos_aft(2)],'-b','linewidth',1);
% % %     plot([z_min z_max],[r_max r_max],'--r','linewidth',1);
% % %     axis equal;
% % %     xlim([z_min z_max]);
% % %     ylim([0 L_y_tot]);
% % % 
% % %     titlename = append('Time step = ',num2str(ts));
% % %     title(titlename);
% % %     set(gca,'fontsize',13);
% % %     savename = append('E_field_amp_BOR_ts=',num2str(ts),'.fig');
% % %     saveas(gca,savename);
% % %     pause(0.1);     
% % % end

if mod(ts,100)==1

    e_interp_vec=e_aft_0_sp;  
    
    N_x_interp=100;        N_y_interp=100;
    
    L_x_st=PML_ll_x_st;
    L_x_end=PML_rr_x_st;
    L_y_st=PML_dd_y_st;
    L_y_end=PML_uu_y_st+pml_length_tot;
    
    [xq,yq,Scat_E_x,Scat_E_y]=...
        Scattered_field_interpolation_3_2D(...
        N_x_interp,N_y_interp,...
        L_x_st,L_x_end,L_y_st,L_y_end,...
        DT,G_mat,e_interp_vec,fac_edg);
    
    tot_E_field_x=Scat_E_x;
    tot_E_field_y=Scat_E_y;
    
    tot_E_field_amp=sqrt( abs(tot_E_field_x).^2+abs(tot_E_field_y).^2 );
    
    close all;
    figure;
    surf(xq,yq,tot_E_field_amp,'edgecolor','none');hold on;
    plot3([z_min z_max],[r_max r_max],[100 100],'--r','linewidth',1);
    axis equal;
    view([0 90]);
    xlim([z_min z_max]);
    ylim([0 L_y_tot]);
    set(gca,'fontsize',13);
    xlabel('z [m]')
    ylabel('\rho [m]')
%     colorbar;
    colormap(hot);
    caxis([0 600]);

%     E_x=zeros(N_2,1);
%     E_y=zeros(N_2,1);
%     for iii=1:N_2
%         ii=iii;
%         E_vec_temp=Wh_1_interp_2D(fac_cent_crdn(ii,:),iii,G_mat,e_aft_0_sp,fac_edg);
%         E_x(iii)=E_vec_temp(1);
%         E_y(iii)=E_vec_temp(2);
%     end
%     sc=5e0;
%     zq=ones(length(fac_cent_crdn(:,1)),1);
%     quiver3(fac_cent_crdn(:,1),fac_cent_crdn(:,2),zq,E_x/sc,E_y/sc,zeros(size(zq)),'b');hold on;
% %         plot(pos_bef_0(1),pos_bef_0(2),'or');
%     plot([pos_bef(1),pos_aft(1)],[pos_bef(2),pos_aft(2)],'-b','linewidth',1);
% %     plot3([z_min z_max],[r_max r_max],[100 100],'--r','linewidth',1);
%     axis equal;
% 
%     titlename = append('Time step = ',num2str(ts));
%     title(titlename);
%     set(gca,'fontsize',13);
    savename = append('E_field_amp_BOR_ts=',num2str(ts),'.png');
    saveas(gca,savename);
%     pause(0.1); 

end

% % %     if mod(ts,100)==1
% % %         e_interp_vec=e_aft_0_sp;  
% % %         
% % %         N_x_interp=500;        N_y_interp=500;
% % %         
% % %         L_x_st=PML_ll_x_st;
% % %         L_x_end=PML_rr_x_st;
% % %         L_y_st=PML_dd_y_st;
% % %         L_y_end=PML_uu_y_st+pml_length_tot;
% % %         
% % %         [xq,yq,Scat_E_x,Scat_E_y]=...
% % %             Scattered_field_interpolation_3_2D(...
% % %             N_x_interp,N_y_interp,...
% % %             L_x_st,L_x_end,L_y_st,L_y_end,...
% % %             DT,G_mat,e_interp_vec,fac_edg);
% % %         
% % %         tot_E_field_x=Scat_E_x;
% % %         tot_E_field_y=Scat_E_y;
% % %         
% % %         tot_E_field_amp=sqrt( abs(tot_E_field_x).^2+abs(tot_E_field_y).^2 );
% % %         
% % %         close all;
% % %         figure;
% % %         surf(xq,yq,tot_E_field_amp,'edgecolor','none');hold on;
% % % %         surf(xq,yq,tot_E_field_x,'edgecolor','none');hold on;
% % %         plot3([z_min z_max],[r_max r_max],[100 100],'--r','linewidth',1);
% % %         axis equal;
% % %         view([0 90]);
% % %         xlim([z_min z_max]);
% % %         ylim([0 L_y_tot]);
% % %         colorbar;
% % %         colormap(redblue);
% % %         caxis([-40 40]);
% % % %         caxis([-2.5 2.5]/2/2/2);
% % % % % %         caxis([-100 100]);
% % % 
% % %         N_x_interp=50;        N_y_interp=50;
% % %         
% % %         L_x_st=PML_ll_x_st;
% % %         L_x_end=PML_rr_x_st;
% % %         L_y_st=PML_dd_y_st;
% % %         L_y_end=PML_uu_y_st+pml_length_tot;
% % %         
% % %         [xq,yq,Scat_E_x,Scat_E_y]=...
% % %             Scattered_field_interpolation_3_2D(...
% % %             N_x_interp,N_y_interp,...
% % %             L_x_st,L_x_end,L_y_st,L_y_end,...
% % %             DT,G_mat,e_interp_vec,fac_edg);
% % %         
% % %         tot_E_field_x=Scat_E_x;
% % %         tot_E_field_y=Scat_E_y;
% % % 
% % %         sc=1e3;%2.5;
% % % % % %         sc=2.5e3;
% % %         zq = ones(size(xq))*1e10;
% % %         quiver3(xq,yq,zq,tot_E_field_x/sc,tot_E_field_y/sc,zeros(size(xq)),0,'b');hold on;
% % % % %         plot(pos_bef_0(1),pos_bef_0(2),'or');
% % % % %         plot(pos_aft(1),pos_aft(2),'ob');
% % % % %         axis equal;
% % % % %         xlim([-1 1]);
% % % % %         ylim([0 2]);
% % % % %         view([0 90]);
% % % % %         colorbar;
% % % % %         colormap(redblue);
% % % % %         set(gca,'fontsize',15);
% % %         xlabel('x [m]');        ylabel('y [m]');
% % %         titlename = append('Time step = ',num2str(ts));
% % %         title(titlename);
% % %         set(gca,'fontsize',13);
% % %         savename = append('E_field_amp_BOR_ts=',num2str(ts),'.fig');
% % %         saveas(gca,savename);
% % %         pause(0.1);        
% % %     end
end
