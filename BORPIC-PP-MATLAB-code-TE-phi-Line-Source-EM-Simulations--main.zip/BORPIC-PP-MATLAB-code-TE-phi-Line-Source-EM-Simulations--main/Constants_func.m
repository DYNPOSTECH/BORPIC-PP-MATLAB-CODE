function [eps_0,mu_0,eta_0,c]=Constants_func()

eps_0=1/36/pi*1e-9;
mu_0=4*pi*1e-7;
eta_0=120*pi;
c=3e8;

end
