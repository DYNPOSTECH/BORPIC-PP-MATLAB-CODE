function [cross_edg_idx,x_crs,y_crs] = Cross_Edg_Idx_Finder_v4(...
    pos_bef,pos_aft,fac_idx,fac_edg,edg_nod,nod_crdn,cross_edg_idx_bef)

x_trj = [pos_bef(1) pos_aft(1)]; 
y_trj = [pos_bef(2) pos_aft(2)]; 

norm_val=zeros(3,1);
cross_edg_idx=zeros(3,1);
x_crs_temp=zeros(3,1);
y_crs_temp=zeros(3,1);
for loc_edg_idx = 1:3
    edg_idx = fac_edg(fac_idx,loc_edg_idx);
    
    edg_x_a = nod_crdn(edg_nod(edg_idx,1),1);
    edg_x_b = nod_crdn(edg_nod(edg_idx,2),1);
    edg_y_a = nod_crdn(edg_nod(edg_idx,1),2);
    edg_y_b = nod_crdn(edg_nod(edg_idx,2),2);
    
    edg_x = [edg_x_a,edg_x_b];
    edg_y = [edg_y_a,edg_y_b];
    
    %line1
    x1  = x_trj;
    y1  = y_trj;
    XY1=[x1;y1];
    %line2
    x2 = edg_x;
    y2 = edg_y;
    XY2=[x2;y2];
    
    xy_intersect=linexlines2D(  XY1(:,1),  XY1(:,2)  , XY2(:,1), XY2(:,2));
    x_crs_temp(loc_edg_idx) = xy_intersect(1);
    y_crs_temp(loc_edg_idx) = xy_intersect(2);
    if isnan(xy_intersect(1))
    else
        norm_val(loc_edg_idx) = norm([x_crs_temp(loc_edg_idx)-pos_bef(1),y_crs_temp(loc_edg_idx)-pos_bef(2)]);
        cross_edg_idx(loc_edg_idx) = edg_idx;   
    end 
end
[rr,~]=find(cross_edg_idx==cross_edg_idx_bef);
norm_val(rr)=[];
cross_edg_idx(rr)=[];
x_crs_temp(rr)=[];
y_crs_temp(rr)=[];
[rr,~]=find(norm_val==max(norm_val));
cross_edg_idx = cross_edg_idx(rr);
x_crs = x_crs_temp(rr);
y_crs = y_crs_temp(rr);
end