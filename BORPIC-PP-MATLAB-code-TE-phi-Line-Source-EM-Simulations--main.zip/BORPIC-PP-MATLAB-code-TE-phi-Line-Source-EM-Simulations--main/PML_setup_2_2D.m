function [cond_set,fac_pml_idx]=...
    PML_setup_2_2D(N_2,...
    PML_ll_x_st,PML_rr_x_st,PML_dd_y_st,PML_uu_y_st,...
    cond_0,h,PML_L,pml_order,fac_cent_crdn)

PML_st_set=zeros(2,2);
PML_st_set(1,1)=PML_ll_x_st;
PML_st_set(1,2)=PML_rr_x_st;
PML_st_set(2,1)=PML_dd_y_st;
PML_st_set(2,2)=PML_uu_y_st;

fac_pml_idx=zeros(N_2,2);
cond_set=zeros(N_2,2);
for i=1:N_2    
    for j=1:2
        if fac_cent_crdn(i,j) <= PML_st_set(j,1) % negative direction
            fac_pml_idx(i,j)=1;

            cond_set(i,j)=cond_0*...
                abs(...
                ( floor( abs( PML_st_set(j,1) - fac_cent_crdn(i,j) )/h)+1 )*h/PML_L ...
                )^pml_order;
        elseif fac_cent_crdn(i,j) >= PML_st_set(j,2) % postive direction
            fac_pml_idx(i,j)=1;

            cond_set(i,j)=cond_0*...
                abs(...
                ( floor( abs( fac_cent_crdn(i,j) - PML_st_set(j,2) )/h)+1 )*h/PML_L ...
                )^pml_order;
        end
        
    end
end

end