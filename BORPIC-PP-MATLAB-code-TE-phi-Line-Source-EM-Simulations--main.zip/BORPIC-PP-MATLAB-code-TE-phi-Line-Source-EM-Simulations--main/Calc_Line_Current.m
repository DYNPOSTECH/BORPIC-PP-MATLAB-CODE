function j_loc=Calc_Line_Current(lambda_loc_s,lambda_loc_f)

j_loc=zeros(3,1);

j_loc(1)=...
    (lambda_loc_s(1)*lambda_loc_f(2)-lambda_loc_f(1)*lambda_loc_s(2));
j_loc(2)=...
    (lambda_loc_s(1)*lambda_loc_f(3)-lambda_loc_f(1)*lambda_loc_s(3));
j_loc(3)=...
    (lambda_loc_s(2)*lambda_loc_f(3)-lambda_loc_f(2)*lambda_loc_s(3));            

end