clear all; clc; close all;

% particle initial
x_bef = [-0.75;1.5];
v_bef = [0.05;0.001]*3e8;

q_sp = 1.61e-19;
m_sp = 9.11e-31;

% Loop antenna z,rho position
loop_ant_crdn=[0,1];

%% Constants
[eps_0,mu_0,eta_0,c]=Constants_func();

% time discretization
del_t=2.5e-11;
N_t=5000;

% wavelength
lambda_0=.5;
k_0=2*pi/lambda_0;
w_0=k_0*c;

% geometry
z_min = -1.5;
z_max = 1.5;
r_min = 0;
r_max = 3;
pml_l = 0.05;
pml_N = 10;
pml_length_tot = pml_l*pml_N;

% pml parameter
PML_ll_x_st=z_min;
PML_rr_x_st=z_max;
PML_dd_y_st=r_min;
PML_uu_y_st=r_max;

PML_N=pml_N;
PML_h=pml_l;
PML_L=pml_length_tot;

pml_order=2;
cond_0=0.;

L_x_tot=abs(z_min)+z_max+2*PML_L;
L_y_tot=r_max+PML_L;

% gaussian quadrature parameter
GC_order_p=2;

%% Mesh information getter
disp('Reading mesh files...') 
tic
load nod_crdn.txt;
load fac_nod.txt;
nod_crdn=nod_crdn(:,2:3);
fac_org_idx=fac_nod(:,1);
fac_nod=fac_nod(:,2:4);
fac_nod=sort(fac_nod,2);
N_0=size(nod_crdn,1);
N_2=size(fac_nod,1);

fac_pml_idx = zeros(N_2,1);
pml_st_org_idx = 10974; %3648;
pml_st_idx = find(fac_org_idx==pml_st_org_idx);
fac_pml_idx(pml_st_idx:end) = 1;
% 1526,3648,4016,4400,4800,5216,5648,6112,6592,7088,7600
toc

% -- checked
disp('Mesh information getter...') 
tic
[...
    N_0,N_1,N_2,DT,...    
    fac_edg,fac_nod,...
    edg_nod,...
    edg_length,...
    nod_crdn]=FEM_2D_Mesh_Getter_gmsh(nod_crdn,fac_nod,N_0,N_2);
toc

% edg_x=[nod_crdn(edg_nod(:,1),1),nod_crdn(edg_nod(:,2),1)]';
% edg_y=[nod_crdn(edg_nod(:,1),2),nod_crdn(edg_nod(:,2),2)]';
% figure;
% plot(edg_x,edg_y,'k');
% axis equal;

disp('X_mat, G_mat, gradient of barycentric coordinates getter...')
tic
[X_mat,G_mat,fac_area]=FEM_2D_X_G_Mat_Gen(N_2,fac_nod,nod_crdn);
toc

disp('DoFs=');
N_1   

% center coordinates of element, face, and edges
[fac_cent_crdn,edg_cent_crdn]=Center_2D_coordinate(...
    N_2,N_1,nod_crdn,fac_nod,edg_nod);


%% Whitney 1 and 2 forms unit vectors
[Wh_1_t_unit_vec,Wh_2_n_unit_vec]=...
    Whitney_1_2_forms_unit_vec_2D(N_1,N_2,nod_crdn,edg_nod,fac_nod);


%% Perfectly Matched Layers
[cond_set,fac_pml_idx]=...
    PML_setup_BOR(N_2,...
    PML_ll_x_st,PML_rr_x_st,PML_dd_y_st,PML_uu_y_st,...
    cond_0,PML_h,PML_L,pml_order,fac_cent_crdn);


%% FEM system matrix
disp('Incidence matrix');
tic
inc_sp_mat=Incidence_Mat_Gen_2D(N_2,N_1,fac_edg);
dual_inc_sp_mat=transpose(inc_sp_mat);
toc

%% L matrix
edg_fac_up_dn = zeros(N_1,2);

% finding edge-face up dn
tic
load edg_fac_up_dn.txt;
% for i=1:N_1
%     nz_col = find( dual_inc_sp_mat(i,:)~=0 );
%     if length(nz_col)==2
%         edg_fac_up_dn(i,:)=nz_col;
%     else
%         edg_fac_up_dn(i,1)=nz_col;
%     end
% end
toc

%% L matrix generation
x_y_opt=1; up_dn_opt=1; 
L_mat_sp_x_up    = L_mat_Gen(edg_fac_up_dn,N_1,N_2,up_dn_opt,x_y_opt,G_mat,fac_area,fac_edg);
x_y_opt=1; up_dn_opt=2; 
L_mat_sp_x_dn  = L_mat_Gen(edg_fac_up_dn,N_1,N_2,up_dn_opt,x_y_opt,G_mat,fac_area,fac_edg);
x_y_opt=2; up_dn_opt=1; 
L_mat_sp_y_up    = L_mat_Gen(edg_fac_up_dn,N_1,N_2,up_dn_opt,x_y_opt,G_mat,fac_area,fac_edg);
x_y_opt=2; up_dn_opt=2; 
L_mat_sp_y_dn  = L_mat_Gen(edg_fac_up_dn,N_1,N_2,up_dn_opt,x_y_opt,G_mat,fac_area,fac_edg);

L_mat_sp = L_mat_sp_x_up + L_mat_sp_x_dn + L_mat_sp_y_up + L_mat_sp_y_dn;

% L_mat_Sanity_Check = L_Mat_Sanity_Check(N_1,N_2,fac_edg,fac_area,G_mat);
% Res_mat = L_mat_Sanity_Check-L_mat_sp;
% sum(sum(abs(L_mat_sp).^2))
% sum(sum(abs(L_mat_Sanity_Check).^2))
% sum(sum(abs(Res_mat).^2))


eps_r = eps_0*fac_cent_crdn(:,2);
mu_r = mu_0./fac_cent_crdn(:,2);

%% W matrix generation
x_y_opt = 1;up_dn_opt = 1;
W_mat_sp_x_up    = W_mat_Gen(cond_set,eps_r,edg_fac_up_dn,N_1,N_2,up_dn_opt,x_y_opt,G_mat,fac_area,fac_edg,del_t);
x_y_opt = 1;up_dn_opt = 2;
W_mat_sp_x_dn  = W_mat_Gen(cond_set,eps_r,edg_fac_up_dn,N_1,N_2,up_dn_opt,x_y_opt,G_mat,fac_area,fac_edg,del_t);
x_y_opt = 2;up_dn_opt = 1;
W_mat_sp_y_up    = W_mat_Gen(cond_set,eps_r,edg_fac_up_dn,N_1,N_2,up_dn_opt,x_y_opt,G_mat,fac_area,fac_edg,del_t);
x_y_opt = 2;up_dn_opt = 2;
W_mat_sp_y_dn  = W_mat_Gen(cond_set,eps_r,edg_fac_up_dn,N_1,N_2,up_dn_opt,x_y_opt,G_mat,fac_area,fac_edg,del_t);

WL_x_up      = W_mat_sp_x_up*L_mat_sp_x_up;
WL_x_dn    = W_mat_sp_x_dn*L_mat_sp_x_dn;
WL_y_up      = W_mat_sp_y_up*L_mat_sp_y_up;
WL_y_dn    = W_mat_sp_y_dn*L_mat_sp_y_dn;


A_eps_mat_sp =  WL_x_up + WL_x_dn + WL_y_up + WL_y_dn;
[r_SP,c_SP]=find(A_eps_mat_sp~=0);
N_nz=length(r_SP);
SP_A_eps_mat_sp = sparse(r_SP,c_SP,ones(N_nz,1));

order_p = 2;
for i=1:order_p-1
    SP_A_eps_mat_sp = SP_A_eps_mat_sp*SP_A_eps_mat_sp;
end
[r_SP_final,c_SP_final]=find(SP_A_eps_mat_sp~=0);
N_nz_final=length(r_SP_final);

I_mat_sp = speye(N_1);

disp('SPAI...')
tic
A_eps_inv_SPAI_mat_sp=SPAI(A_eps_mat_sp, SP_A_eps_mat_sp, I_mat_sp, N_1);
toc



L_z_mat_sp_mat = L_z_mat_Gen(N_2,fac_area);
W_z_mat_sp_mat = W_z_mat_Gen(cond_set,N_2,del_t,mu_r);

A_mu_inv_mat_sp = W_z_mat_sp_mat*L_z_mat_sp_mat;

% A_mu_inv_mat_sp_Sanity_Check = Mu_inv_mass_Mat_Gen_PML(N_2,fac_area,cond_set,w_0);
% Res_mat = A_mu_inv_mat_sp_Sanity_Check-A_mu_inv_mat_sp;
% sum(sum(abs(A_mu_inv_mat_sp_Sanity_Check).^2))
% sum(sum(abs(A_mu_inv_mat_sp).^2))
% sum(sum(abs(Res_mat).^2))

% dynamical variables
b_bef_0_sp=sparse(N_2,1);         % n-1/2
b_bef_1_sp=sparse(N_2,1);         % n-1/2
b_bef_2_sp=sparse(N_2,1);         % n-1/2

b_aft_0_sp=sparse(N_2,1);         % n+1/2
b_aft_1_sp=sparse(N_2,1);         % n+1/2
b_aft_2_sp=sparse(N_2,1);         % n+1/2

h_bef_0_sp=sparse(N_2,1);         % n-1/2
h_bef_1_sp=sparse(N_2,1);         % n-1/2
h_bef_2_sp=sparse(N_2,1);         % n-1/2

h_aft_0_sp=sparse(N_2,1);         % n+1/2
h_aft_1_sp=sparse(N_2,1);         % n+1/2
h_aft_2_sp=sparse(N_2,1);         % n+1/2

d_bef_0_sp=sparse(N_1,1);         % n
d_aft_0_sp=sparse(N_1,1);         % n+1

d_bef_0_x_up_sp = sparse(N_1,1);
d_bef_0_x_dn_sp = sparse(N_1,1);
d_bef_0_y_up_sp = sparse(N_1,1);
d_bef_0_y_dn_sp = sparse(N_1,1);

d_bef_1_x_up_sp = sparse(N_1,1);
d_bef_1_x_dn_sp = sparse(N_1,1);
d_bef_1_y_up_sp = sparse(N_1,1);
d_bef_1_y_dn_sp = sparse(N_1,1);

e_bef_0_sp=sparse(N_1,1);         % n
e_aft_0_sp=sparse(N_1,1);         % n+1

e_bef_0_x_up_sp = sparse(N_1,1);
e_bef_0_x_dn_sp = sparse(N_1,1);
e_bef_0_y_up_sp = sparse(N_1,1);
e_bef_0_y_dn_sp = sparse(N_1,1);

e_bef_1_x_up_sp = sparse(N_1,1);
e_bef_1_x_dn_sp = sparse(N_1,1);
e_bef_1_y_up_sp = sparse(N_1,1);
e_bef_1_y_dn_sp = sparse(N_1,1);

% del_t=1e-11;
% N_t=1e3;
source_opt=2;
time=[0:del_t:(N_t-1)*del_t];
f_source=zeros(N_t,1);
if source_opt == 1
    v_c=c/4;
    for ts = 1:N_t
        if time(ts) < lambda_0/v_c
            f_source(ts) = -0.488*sin(2*pi*time(ts)*v_c/lambda_0)...
                +0.290*sin(4*pi*time(ts)*v_c/lambda_0)...
                -0.031*sin(6*pi*time(ts)*v_c/lambda_0);
        end
    end
else
    per=4;
    for ts = 1:N_t
        if time(ts) < per*2*pi/w_0
            f_source(ts) = sin(w_0*time(ts));
        end
    end
end

figure;
plot(time,f_source);

% stop

dist=zeros(N_1,1);
for i=1:N_1
    dist(i,1) = sqrt( (edg_cent_crdn(i,1) - loop_ant_crdn(1))^2 + (edg_cent_crdn(i,2) - loop_ant_crdn(2))^2 );
end
ant_idx=find(dist==min(dist));

for ts = 1:N_t
    disp(append('time index = ',num2str(ts)))
    
    
    if ts>1
        % dynamical variable update
        b_bef_0_sp = b_aft_0_sp;
        h_bef_0_sp = h_aft_0_sp;
        d_bef_0_sp = d_aft_0_sp;     
        e_bef_0_sp = e_aft_0_sp;

        x_bef = x_aft;
        v_bef = v_aft;
    end
    
    %% Discrete Faraday's law for b_aft
    b_aft_0_sp = b_bef_0_sp - del_t*inc_sp_mat*e_bef_0_sp;    
    h_aft_0_sp = A_mu_inv_mat_sp*b_aft_0_sp;            

    j_bef = zeros(N_1,1);

    % particle update
    for p_idx = 1

        % gathering
        e_dof = e_bef_0_sp;
        b_dof = (b_bef_0_sp+b_aft_0_sp)/2;
        fac_idx = Find_Fac(x_bef,fac_cent_crdn,nod_crdn,fac_nod);
        E_field_val = E_field_Interpolation_2D(x_bef,fac_idx,G_mat,e_dof,fac_edg);
        B_field_val = B_field_Interpolation_2D(b_dof,fac_idx,fac_area,fac_nod,nod_crdn);

        E_field_gather = [E_field_val;0];
        B_field_gather = [0;0;B_field_val];
        
        % push
        LF_fac=q_sp*del_t/m_sp;

        N_mat = [1,-LF_fac/2*B_field_val,0;LF_fac/2*B_field_val,1,0;0,0,1];
        N_mat_inv = inv(N_mat);
        N_mat_trs = transpose(N_mat);

        v_aft = N_mat_inv*(N_mat_trs*[v_bef;0] + LF_fac*E_field_gather);
        v_aft = v_aft(1:2);
        x_aft = x_bef + del_t*v_aft;

        % scatter
        fac_idx_bef = fac_idx;
        fac_idx_aft = Find_Fac(x_aft,fac_cent_crdn,nod_crdn,fac_nod);

        if fac_idx_bef==fac_idx_aft % in face during Delta t
            G_mat_temp = G_mat(:,:,fac_idx_bef);
            lambda_loc_s=G_mat_temp*[x_bef;1];
            lambda_loc_f=G_mat_temp*[x_aft;1];

            j_loc=Calc_Scatter_Current(lambda_loc_s,lambda_loc_f,q_sp,del_t);
            for j=1:3
                j_bef(fac_edg(fac_idx_bef,j),1)=j_bef(fac_edg(fac_idx_bef,j),1)+j_loc(j);
            end                

        else % travel interfaces during Delta t            
            [cross_edg_idx,x_crs,y_crs] = Cross_Edg_Idx_Finder(...
                        x_bef,x_aft,fac_idx_bef,fac_edg,edg_nod,nod_crdn);

            rr_idx = find(fac_idx_bef == edg_fac_up_dn(cross_edg_idx,:));
            fac_idx_temp = edg_fac_up_dn(cross_edg_idx,rr_idx);            

            x_bef_temp = x_bef;
            x_aft_temp = [x_crs;y_crs];
            G_mat_temp = G_mat(:,:,fac_idx_temp);
            lambda_loc_s=G_mat_temp*[x_bef_temp;1];
            lambda_loc_f=G_mat_temp*[x_aft_temp;1];

            j_loc=Calc_Scatter_Current(lambda_loc_s,lambda_loc_f,q_sp,del_t);
            for j=1:3
                j_bef(fac_edg(fac_idx_bef,j),1)=j_bef(fac_edg(fac_idx_bef,j),1)+j_loc(j);
            end

            rr_idx = find(fac_idx_bef ~= edg_fac_up_dn(cross_edg_idx,:));
            fac_idx_temp = edg_fac_up_dn(cross_edg_idx,rr_idx);            

            if fac_idx_temp ~= fac_idx_aft
                error
            end

            x_bef_temp = [x_crs;y_crs];
            x_aft_temp = x_aft;
            G_mat_temp = G_mat(:,:,fac_idx_temp);
            lambda_loc_s=G_mat_temp*[x_bef_temp;1];
            lambda_loc_f=G_mat_temp*[x_aft_temp;1];

            j_loc=Calc_Scatter_Current(lambda_loc_s,lambda_loc_f,q_sp,del_t);
            for j=1:3
                j_bef(fac_edg(fac_idx_bef,j),1)=j_bef(fac_edg(fac_idx_bef,j),1)+j_loc(j);
            end

        end
        j_bef_sp=sparse(j_bef);
    end


    %% Discrete Ampere's law for d_aft
    d_aft_0_sp = d_bef_0_sp + del_t*dual_inc_sp_mat*h_aft_0_sp - del_t*j_bef_sp;    
    e_aft_0_sp = A_eps_inv_SPAI_mat_sp*d_aft_0_sp;   

    if mod(ts,500)==1

        e_interp_vec=e_aft_0_sp;  
        
        N_x_interp=30;
        N_y_interp=30;
        
        L_x_st=PML_ll_x_st-PML_L;
        L_x_end=PML_rr_x_st+PML_L;
        L_y_st=PML_dd_y_st;
        L_y_end=PML_uu_y_st+PML_L;
        
        [xq,yq,Scat_E_x,Scat_E_y]=...
            Scattered_field_interpolation_3_2D(...
            N_x_interp,N_y_interp,...
            L_x_st,L_x_end,L_y_st,L_y_end,...
            DT,G_mat,e_interp_vec,fac_edg);
        
        tot_E_field_x=Scat_E_x;
        tot_E_field_y=Scat_E_y;
        
        tot_E_field_amp=sqrt( abs(tot_E_field_x).^2+abs(tot_E_field_y).^2 );
        
        figure;
        quiver(xq,yq,tot_E_field_x,tot_E_field_y);
%         surf(xq,yq,tot_E_field_x,'edgecolor','none');hold on;
%         plot([z_min z_max],[r_max r_max],'r','linewidth',1);
%         plot([z_min z_min],[r_min r_max],'r','linewidth',1);
%         plot([z_max z_max],[r_min r_max],'r','linewidth',1);
        view([0 90]);
        axis equal;
        colorbar;
        colormap(redblue)
%         caxis([-20 -9]);
        set(gca,'fontsize',15);
        xlabel('x [m]');        ylabel('y [m]');
        titlename = append('Time step = ',num2str(ts));
        title(titlename);
        savename = append('E_field_amp_BOR_ts=',num2str(ts),'.png');
        saveas(gca,savename);
        pause(1);
        close all;
    end

end
