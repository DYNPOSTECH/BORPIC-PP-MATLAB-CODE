function A_eps_inv_SPAI_mat_sp=SPAI(A_eps_mat_sp, SP_A_eps_mat_sp, I_mat_sp, N_1)

A_eps_inv_SPAI_mat_sp_i = zeros(20*N_1,1);
A_eps_inv_SPAI_mat_sp_j = zeros(20*N_1,1);
A_eps_inv_SPAI_mat_sp_v = zeros(20*N_1,1);

cnt_en = 0;
for k=1:N_1
    m_k = full(SP_A_eps_mat_sp(:,k));
    J_col_ind_vec = find(m_k ~= 0);
    [I_row_ind_vec,~] = find(A_eps_mat_sp(:,J_col_ind_vec)~=0);
    A_bar = full(A_eps_mat_sp(I_row_ind_vec,J_col_ind_vec));
    
    e_k = full(I_mat_sp(:,k));
    e_bar_k = e_k(I_row_ind_vec);    
    m_bar_k_upd = A_bar\e_bar_k; 
    
    N_nz = length(m_bar_k_upd);

    cnt_st = cnt_en+1;
    cnt_en = cnt_st+(N_nz-1);
    A_eps_inv_SPAI_mat_sp_i(cnt_st:cnt_en) = J_col_ind_vec;
    A_eps_inv_SPAI_mat_sp_j(cnt_st:cnt_en) = ones(N_nz,1)*k;
    A_eps_inv_SPAI_mat_sp_v(cnt_st:cnt_en) = m_bar_k_upd;
end

A_eps_inv_SPAI_mat_sp_i(cnt_en+1:end) = [];
A_eps_inv_SPAI_mat_sp_j(cnt_en+1:end) = [];
A_eps_inv_SPAI_mat_sp_v(cnt_en+1:end) = [];

A_eps_inv_SPAI_mat_sp=sparse(A_eps_inv_SPAI_mat_sp_i,A_eps_inv_SPAI_mat_sp_j,A_eps_inv_SPAI_mat_sp_v,N_1,N_1);

end