function res=Continuity_Equation(q_bef,q_aft,j_bef,dual_inc_mat_sp,del_t)
    res = dual_inc_mat_sp*j_bef + (q_aft-q_bef)/del_t;
end